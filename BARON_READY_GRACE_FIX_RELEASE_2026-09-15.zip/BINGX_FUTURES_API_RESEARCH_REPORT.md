# BingX — USDT-M Perpetual Futures: Order Execution & Position Management — Official Docs Research Report

**Scope:** Current official BingX documentation only (API reference + BingX product docs). Verifies whether a trading engine's assumptions match exchange behavior.
**Research date:** 2026-09-08
**Legend per area item:**
- **(a)** official field / endpoint names
- **(b)** exact quotes + numbers
- **(c)** exact source URLs read
- **(d)** one‑line keyword summary
- Anything **not** provable from the official sources below is stamped **`UNVERIFIED_FROM_OFFICIAL_DOCS`**.

---

## Source Register (everything actually read/queried)

| # | Source | What it is | How read | Status |
|---|--------|-----------|----------|--------|
| S1 | `https://bingx-api.github.io/docs-v3/#/en/info` | Current BingX API reference (JS SPA; the older `bingx-api.github.io/docs` redirects here) | SPA content lives in the webpack bundle `https://bingx-api.github.io/docs-v3/static/js/app.0faf11fb00445c19dd82.js`, which was downloaded and parsed (module data, tables, `info.en` notes). All API quotes below are exact words from that bundle. | ✅ |
| S2 | Error tables page (bundle) — official anchor: `https://bingx-api.github.io/docs-v3/#/en/Quick%20Start/Error%20Code%20Reference?anchor=cat-futures` (URL literal is what the API pages link to: "Error Code Reference - Futures Error Codes") | USDT-M/Coin-M futures EN error table + zh error table, embedded in bundle | Parsed the HTML tables out of the bundle | ✅ |
| S3 | `https://open-api.bingx.com/openApi/swap/v2/quote/contracts?symbol=BTC-USDT` | Live official server endpoint | Queried live 2026-09-08, returned `code:0` + full BTC-USDT row | ✅ |
| S4 | `https://bingx.com/en/support/articles/17917912060569/` | Perpetual Futures \| Order Types (limit/market/trigger/trailing/post-only/TP-SL) | Full page fetched (webfetch) | ✅ |
| S5 | `https://bingx.com/en/support/articles/15074354955791` | Perpetual Futures: Major Upgrade to TP/SL (2026-02-02) — Entire vs Partial TP/SL model | Read via search-indexed page content | ✅ |
| S6 | `https://bingx.com/en/support/articles/6693665893017` | An Introduction to Partial TP/SL | Read via search-indexed page content | ✅ |
| S7 | `https://bingx.com/en/support/articles/21627055198873` | Perpetual Futures \| FAQ on TP/SL | Read via search-indexed page content | ✅ |
| S8 | `https://bingx.com/en/support/articles/26392412034713` | Perpetual Futures \| Introducing Position TP/SL | Read via search-indexed page content | ✅ |
| S9 | `https://bingx.com/en/learn/article/stop-loss-take-profit` | Learn: Stop-Loss / Take-Profit (Unified TP/SL model) | Read via search-indexed page content | ✅ |
| S10 | `https://bingx.com/en/support/articles/39958644800537` | BingX Update API Trading Rules (2025-12-02) — cancellation-rate restrictions | Read via search-indexed page content | ✅ |
| S11 | `https://bingx.com/en/support/articles/360045899754` | Perpetual Futures \| Trading Pairs, Leverage and Limits | Read via search-indexed page content (partly) | ⚠️ nav/partial |
| S12 | `https://bingx.com/en/support/articles/26005528258457` | Unification of Maximum Position Limits for Perpetual & Standard Futures | Read via search-indexed page content | ✅ |
| S13 | `https://bingx.com/en/support/articles/360055681174` | About Order Type (Perpetual Futures) | Read via search-indexed page content | ✅ |
| S14 | `https://bingx.com/en/tradeInfo/perpetual/trading-rules/BTC-USDT` | Live per-symbol trading rules page | Returns only site nav (JS-rendered); no table content retrievable | ⚠️ **blocked — dynamic page** |

---

## Area 1 — Hedge Mode & `positionSide` (with error semantics)

**(a) Endpoints/fields**
- `POST /openApi/swap/v1/positionSide/dual` (Set position mode) — rate `4/second`, ip `2/second`
- `GET /openApi/swap/v1/positionSide/dual` (Query position mode) — rate `2/second`, ip `2/second`
- Order placement carries `positionSide` and `side` per order.

**(b) Exact quotes (S1 bundle)**
- GET response field `dualSidePosition`: `"true": dual position mode; "false": single position mode`.
- POST info note: `*The Position Mode applies to all contracts and can be set when there are no active positions or pending orders.` (zh: "若存在持倉或掛單，則不支援調整倉位模式。")
- POST endpoint description: `Used to set the position mode of perpetual contract, supporting both dual position mode and single [position mode]`.
- Place order (`POST /openApi/swap/v2/trade/order`) parameter `positionSide`: `Position direction, required for single position as BOTH, for both long and short positions only LONG or SHORT can be chosen, defaults to LONG if empty`.
- Official open/close combination table (bundle info note):
  ```
  open/buy LONG:   side=BUY  & positionSide=LONG
  close/sell LONG: side=SELL & positionSide=LONG
  open/sell SHORT: side=SELL & positionSide=SHORT
  close/buy SHORT: side=BUY  & positionSide=SHORT
  ```
- `positionId` (place order param): `Not required in regular Hedge Mode. Required only when closing a position in Separate Isolated mode.`
- Positions response `positionSide`: `position direction LONG/SHORT long/short` (`GET /openApi/swap/v2/user/positions`).
- `GET /openApi/swap/v2/user/positions` response `isolated`: `Whether it is isolated margin mode, true: isolated margin mode false: cross margin`.

**Error semantics (S2, cat-futures table):**
- `109400` — `Invalid request parameters. Common reasons: … Position mode mismatch (e.g. PositionSide must be BOTH in one-way mode)` (zh: "持倉模式與參數不匹配（如單向模式下 PositionSide 須為 BOTH）").
- `104103` — `Cannot switch position mode while positions or pending orders exist. Close all positions and cancel all orders first.` (zh: "存在持倉或掛單，無法切換持倉模式").
- `104108` — `One-way position mode does not support separate isolated margin mode. Switch to Hedge mode first.`

**(c) Sources:** S1 (bundle: positionSide/dual GET+POST, trade/order, user/positions), S2 (error table).
**(d)** One-way mode forces `positionSide=BOTH`; hedge mode uses `LONG`/`SHORT` per side; mode switch rejected while any position/open order exists (`104103`); `positionSide` defaults to LONG; hedge mode + ONE separate isolated mode needs `positionId` on close.

---

## Area 2 — `reduceOnly` semantics (what happens if it exceeds position)

**(a) Field**
- `reduceOnly` on `POST /openApi/swap/v2/trade/order` (string `true/false`).

**(b) Exact quotes (S1/S2)**
- Place-order param: `true, false; defaults to false in One-way Mode; do not send this parameter in Hedge Mode`.
- Order-history response (`GET /openApi/swap/v2/trade/allOrders`) `reduceOnly`: `true, false; Default value is false for single position mode; This parameter is not accepted for both long and short positions mode`.
- Place-order response `reduceOnly`: `Whether the returned order is reduce-only: true or false. This field is not used in Hedge Mode.`
- **Exceeds-position behavior** — error `101290` (S2 EN table): `A Reduce Only order can only decrease an existing position. Ensure the order does not exceed the current position size.`
- Closely related close-side errors: `101205` `No position exists to close. Query positions first to confirm a position exists.` · `110203` `Available amount for closing is insufficient. Reduce closing quantity or wait for pending orders to fill.` (zh: "可平倉數量不足。請減少平倉數量或等待掛單成交後重試。") · `109420` `No position exists for the specified symbol. Query position information first.`

**(c) Sources:** S1 (trade/order param + response, allOrders response), S2 (error table).
**(d)** In one-way mode reduceOnly defaults false and acts as a hard "close-only" guard → order that would open/oversize is rejected with `101290`; in hedge mode the param must not be sent at all (closing is expressed via `side`+`positionSide`).

---

## Area 3 — Order types + partial vs entire TP/SL

**(a) Fields / types**
- `type` values (S1): `LIMIT, MARKET, STOP_MARKET, TAKE_PROFIT_MARKET, STOP, TAKE_PROFIT, TRIGGER_LIMIT, TRIGGER_MARKET, TRAILING_STOP_MARKET, TRAILING_TP_SL`
  with official EN labels: `LIMIT: Limit Order / MARKET: Market Order / STOP_MARKET: Stop Market Order / TAKE_PROFIT_MARKET: Take Profit Market Order / STOP: Stop Limit Order / TAKE_PROFIT: Take Profit Limit Order / TRIGGER_LIMIT: Stop Limit Order with Trigger / TRIGGER_MARKET: Stop Market Order with Trigger / TRAILING_STOP_MARKET: [Trailing Stop] / TRAILING_TP_SL: [Trailing TP/SL]`.
- `timeInForce`: `Time in Force, currently supports PostOnly, GTC, IOC, and FOK`.
- Trailing params: `price` = `the trailing stop distance in TRAILING_STOP_MARKET and TRAILING_TP_SL`; `priceRate` = `For type: TRAILING_STOP_MARKET or TRAILING_TP_SL; Maximum: 1`; `activationPrice` = `Used with TRAILING_STOP_MARKET or TRAILING_TP_SL orders, default as the latest price (supporting different workingType)`.
- `workingType` = `MARK_PRICE, CONTRACT_PRICE, or INDEX_PRICE, with the default set to MARK_PRICE`.
- `stopGuaranteed` = `true: Enables the guaranteed stop-loss and take-profit feature; … cutfee: Enable the guaranteed stop loss function and enable the VIP guaranteed stop loss fee reduction`.
- Attach-at-open TP/SL: `stopLoss`: `Support setting stop loss while placing an order. Only supports type: STOP_MARKET/STOP`; `takeProfit`: `Support setting take profit while placing an order. Only supports type: TAKE_PROFIT_MARKET/TAKE_PROFIT`.

**(b) Exact quotes**
- Trigger semantics (S1 info note): `STOP/STOP_MARKET Stop loss order:` `The cumulative quantity of placed stop-loss orders cannot be greater than the position quantity` · `Buy: The mark price is higher than or equal to the trigger price stopPrice` · `Sell: The mark price is lower than or equal to the trigger price stopPrice`. `TAKE_PROFIT/TAKE_PROFIT_MARKET Take profit order:` `The cumulative quantity of pending stop-profit orders cannot be greater than the position quantity` · `Buy: The mark price is lower than or equal to the trigger price stopPrice` · `Sell: The mark price is higher than or equal to the trigger price stopPrice`.
- Product (S4): Trailing stop: `When the market moves in a favorable direction for the investor and reaches their desired trigger price, the trailing order automatically initiates an open position on their behalf.` Activation: `(1) If an activation price is filled in, the system will start calculating the trigger price in real time when the activation price is reached. (2) If an activation price is not filled in, the order is activated immediately after being placed, and the trigger price is calculated in real-time.`
- Product (S4) TP/SL freeze: `The settings for TP and SL orders apply only to existing positions. Therefore, the corresponding position quantity will be frozen.` TP/SL direction rule: `When selling, the TP trigger is higher than the last filled price, while the SL trigger is lower than the last filled price. When buying, the TP trigger is lower than the last filled price, and the SL trigger is higher than the last filled price.`
- **Entire vs Partial model** (S5): `Entire position corresponds to the previous version's Position TP/SL. Partial position corresponds to the previous version's TP/SL.` (S8 Position TP/SL): `Position TP/SL enables users to take profit or stop loss for an entire position. The TP/SL amount dynamically adjusts as the position size changes (either increased or decreased). … Position TP/SL is executed as market orders …` and `Position TP/SL does not support One-Way Mode.` (S5/Partial): users `can split their holdings and set multiple TP and SL orders (and can set a total order amount exceeding 100% of the current actual holdings)`. Lite futures: `The Lite version of Perpetual Futures does not support partial position TP/SL, and Coin-M Perp Futures do not support position TP/SL.`

**(c) Sources:** S1, S4, S5, S8.
**(d)** 10 order types (incl. trailing); TP/SL can be attached at order time; product distinguishes **Entire-position TP/SL** (dynamic qty, market-only, no one-way) vs **Partial-position TP/SL** (up to 20 sets, market or limit, >100% total allowed).

---

## Area 4 — TP/SL behavior after partial close (does remaining auto-adjust?)

**(b) Exact quotes (all product docs)**
- FAQ (S7) Q.6 — auto-adjustment of max closeable: `if you hold a position of 50 BTC, your maximum allowable TP/SL amount is 50 BTC. Should you close 10 BTC from that position through any method, the available amount of that specific position for TP/SL will automatically adjust to 40 BTC.`
- FAQ (S7) VII: `1. Closing a position will affect the contract size of TP/SL orders. If a position is closed, the corresponding TP/SL order will be canceled.`
- Partial TP/SL (S6) manual-partial-close rule table: `After reducing the position margin, if the TP/SL is larger than the current margin, users can reduce the Closing Margin for each setting (starting from the earliest one) until the combined Closing Margin equals the current margin. Users need to handle TP and SL separately according to the rule above. Otherwise, the TP/SL parameters will not be updated.`
- Worked example (S6): `The user closes out 350 USDT position, leaving the remaining margin at 150 USDT … 1. The SL order with Partial SL at 200 USDT (40%) and an SL trigger price of 3400 USDT will be canceled in the first place; 2. The SL order with Partial SL of 200 USDT (40%) and an SL trigger price of 3000 USDT will be updated from 200 USDT-> 150 USDT / 40%-> 100% / Price 3000 USDT.`
- OCO (S5): `If both TP and SL are set, once either is triggered and executed, the other will be automatically canceled to ensure that only one side is executed.` (S7 Scenario 3: `At the same time, the SL order with a trigger price of $18,000 will be canceled.` S9: `Yes. BingX uses OCO (One Cancels the Other) logic. Once one is triggered, the other is automatically canceled to prevent an unintended new position from opening.`)
- Entire-position dynamic adjust on add (S9): `If you hold 1 BTC with an Entire Position SL and then buy another 0.5 BTC, the system automatically updates your SL quantity to 1.5 BTC.` and on manual reduce: `In the 2026 Unified Model, if you manually reduce your position size, the system may automatically adjust your Entire Position TP/SL quantities to keep your risk-reward ratio consistent.` Partial does **not** auto-scale up: `Fixed Quantities: These orders do not automatically scale. If you add to your position, you must manually assign new TP/SL orders to the additional margin.`
- Unified-pair rule (S5): `if users set both TP and SL during order creation, the system will manage both as part of the same set of parameters. When users adjust the TP or SL amount, the system will simultaneously update the amount for the other (SL or TP). … The above logic applies only to scenarios where both TP and SL are set simultaneously during order creation.`
- API-level caps consistent with above (S1 + S2): `The cumulative quantity of placed stop-loss orders cannot be greater than the position quantity`; error `110203` (`insufficient closeable amount`), `110206` (`TP/SL orders reached the maximum limit` / zh "止盈/止損掛單數量已達上限"), max `20 TP/SL settings` (S6: `You can create up to 20 TP/SL settings`).
- Margin rule after partial TP/SL (S6): `You can increase the margin but not reduce the position margin because a reduction in position margin could trigger TP/SL instantly.`

**(c) Sources:** S1, S2, S5, S6, S7, S8, S9.
**(d)** Yes — remaining TP/SL auto-reduce/cancel after manual partial closes (earliest set canceled first, later sets shrunk to remaining), OCO on trigger; API constrains TP/SL total ≤ position and max 20 sets; no official statement exists that API-created TP/SL orders are *auto-restructured* after a partial close — **that specific API-level behavior: `UNVERIFIED_FROM_OFFICIAL_DOCS`.**

---

## Area 5 — Fill behavior, positions & trade-history fields

**(a) Endpoints/fields**
- `POST /openApi/swap/v2/trade/order` response → `orderID` (capital D!), `status`, `avgPrice`, `executedQty`, `positionSide`, `reduceOnly`, `clientOrderId`, `stopGuaranteed`, `workingType`.
- `GET /openApi/swap/v2/trade/order` (Query Order details) / `GET /openApi/swap/v2/trade/allOrders` (Query Order history; 7-day window) / `GET /openApi/swap/v2/trade/openOrders`.
- `GET /openApi/swap/v2/trade/fillHistory` (my-trades equivalent; `startTs`/`endTs` required; `pageSize` default 50, max 1000).
- `GET /openApi/swap/v2/user/positions` (rate 10/s, ip 3/s).
- `GET /openApi/swap/v2/trade/positionHistory` (90-day range; `pageSize` default 100, max 1000).
- `GET /openApi/swap/v2/user/income` (fund-flow; `limit` default 100, max 1000).

**(b) Exact quotes (S1)**
- Order-status enum (single source of truth): `Order status: NEW(New order)/PENDING(Pending)/FILLED(Filled)/PARTIALLYFILLED(Partially filled)/CANCELLED(Cancelled)/FAILED(Failed)`. (History response adds `CANCELED` spelling: `NEW / PENDING / PARTIALLY_FILLED / FILLED / CANCELED / FAILED`.)
- AllOrders/Order-details response fields (official names): `time, symbol, side, type, positionSide, reduceOnly, cumQuote ("transaction amount"), status, stopPrice, price, origQty ("original order quantity"), avgPrice ("average transaction price"), executedQty ("volume"), orderId, profit ("profit and loss"), commission ("Fee"), updateTime, clientOrderId, workingType, stopGuaranteed, triggerOrderId, closePosition ("Whether to close the entire position")»; TWAP extras `isTwap, mainOrderId`.
- Place-order response `avgPrice`: `Average filled price, present when type=MARKET`; `executedQty`: `Transaction quantity, coins`.
- Fill history (myTrades) fields: `symbol, qty ("Transaction quantity"), quoteQty ("Transaction amount"), price ("Transaction price"), commission, commissionAsset, tradeId, orderId, filledTime, clientOrderID, realisedPNL, side, positionSide, role ("Active selling and buying, taker: active buying, maker: active selling")`.
- Open orders item additionally carries `takeProfit` / `stopLoss` sub-objects (`type, quantity, stopPrice, price, workingType`) and `trailingStopRate, trailingStopDistance, postOnly`.
- Positions (`user/positions`) fields: `positionId, symbol, currency, positionSide, isolated (true=isolated margin, false=cross), positionAmt ("Position Amount"), availableAmt, unrealizedProfit, realisedProfit, initialMargin, margin, liquidationPrice, avgPrice ("Average opening price"), leverage, positionValue, markPrice, riskRate ("Risk rate. When the risk rate reaches 100%, it will force liquidation or position reduction"), maxMarginReduction, pnlRatio, updateTime`. Broad note: `code=0 with data=[] means that the query succeeded and no positions matched the query conditions`; `code=109500 means that the position query failed. Do not treat it as confirmation that the account has no positions; retry later.`
- Position history fields: `positionId, positionSide (LONG/SHORT), isolated (true: isolated, false: cross), closeAllPositions ("All positions closed"), positionAmt, closePositionAmt, realizedProfit, netProfit, avgClosePrice, avgPrice ("Average open price"), leverage, positionCommission, totalFunding, openTime, updateTime ("Close time")`.
- Income (`user/income`): `symbol, incomeType ("money flow type"), income ("positive = inflow"), asset, info, time, tranId, tradeId`; `incomeType` values (export endpoint): `REALIZED_PNL FUNDING_FEE TRADING_FEE INSURANCE_CLEAR TRIAL_FUND ADL SYSTEM_DEDUCTION`.

**(c) Sources:** S1.
**(d)** Fill data lives in `allOrders`/`order` (`executedQty`, `cumQuote`, `avgPrice`, `profit`, `commission`) and `fillHistory` (`qty`, `price`, `quoteQty`, `commission`, `realisedPNL`, `role`); `user/positions` gives `positionAmt`/`avgPrice`/`unrealizedProfit`/`liquidationPrice`/`riskRate`; always check `code` (109500 ≠ no positions).

---

## Area 6 — Cancel/replace, order limits, min size, precision, trigger rules

**(a) Endpoints**
- `DELETE /openApi/swap/v2/trade/order` (Cancel Order) — rate `10/second`, ip `3/second`. Params: `orderId` (opt), `clientOrderId` (opt), `symbol` (required), `timestamp`, `recvWindow`. Response `data.order` returns the order with `status: CANCELLED`.
- `POST /openApi/swap/v1/trade/cancelReplace` (Cancel-Replace) — rate `5/second`, ip `2/second`. Params `cancelReplaceMode`, `cancelOrderId`/`cancelClientOrderId`, `cancelRestrictions`, plus new-order fields + optional `takeProfit`/`stopLoss` sub-orders. Response: `cancelResult, cancelMsg, cancelResponse{…}, replaceResult, replaceMsg, newOrderResponse{orderId, symbol, positionSide, side, type, price, quantity, stopPrice, workingType, clientOrderId, timeInForce, priceRate, stopLoss, takeProfit, reduceOnly}`.
- `POST /openApi/swap/v1/trade/amend` (Modify Order) — rate `5/second`. Params: `orderId` or `clientOrderId` (`Either orderId or clientOrderId must be provided. At least one of them is required.`), `quantity` (`The amended order quantity.`), `symbol` (required, uppercase). Response: `code, msg, orderId, clientOrderId, symbol, quantity`.
- `POST /openApi/swap/v2/trade/cancelAllAfter` (kill-switch) — rate `1/second`, ip `2/second`: `type: ACTIVATE-Activate, CLOSE-Close`; `timeOut: Activate countdown time (seconds), range: 10s-120s`; batch note: pending orders are canceled `in batches, which may take several seconds … the system will reject further ACTIVATE and CLOSE requests` until done. *(Doc quirk: the bundled example `note` text says "spot pending orders" although the endpoint is `swap/v2` — flagged as doc copy-paste.)*
- Order-limit errors: `101419` `Pending orders reached the upper limit. Cancel some pending orders first.` (zh: "掛單數量已達上限。請先取消部分掛單後再下新單。"); `110206` TP/SL order-count cap; `112414` `The total position amount has reached the platform limit.`

**(b) Exact quotes / numbers**
- **Maximum pending orders:** the official docs state only that a cap exists (`101419`). **No numeric max-pending-orders value for USDT-M futures is published in S1–S14 → numeric cap: `UNVERIFIED_FROM_OFFICIAL_DOCS`.**
- **Cancellation-rate restrictions** (S10, effective 2025-12-02): `Buying restrictions will be triggered if the number of orders in the past hour exceeds the threshold and the order cancellation rate is over 99% (selling is not affected). These restrictions will be automatically lifted after 10 minutes.` Table: Total cancellation rate — 2,000 orders/1h, ≥99% → all buy orders; Limit orders — 500, ≥99% → limit buys; Maker (Post Only) — 500, ≥99% → PostOnly buys; IOC — 500, ≥99%; FOK — 500, ≥99%. `*Order cancellation rate = number of canceled orders ÷ total historical orders`.
- **Trigger rules** (S1): Stop loss `Buy: mark ≥ trigger … Sell: mark ≤ trigger`; Take profit `Buy: mark ≤ trigger … Sell: mark ≥ trigger` (full text in Area 3). Product (S4): `Before a trigger order is triggered, neither the margin nor the position is frozen.`
- **Price bands** (S4): limit `price … capped at 10% of the average mark price in the last 5 minutes (it varies for different trading pairs …)` and `Pending orders whose price deviates from the mark price for over 10% for more 7 days will be automatically canceled.` Market slippage protection: `the price can deviate by up to 2%. Any portion that exceeds this limit won't be filled, and the system will automatically cancel the order.`
- **Center precision / min size** (S3, live, 2026-09-08, BTC-USDT):
  ```
  quantityPrecision: 4   pricePrecision: 1
  tradeMinQuantity: 0.0001   tradeMinUSDT: 2   size: 0.0001
  makerFeeRate: 0.0002   takerFeeRate: 0.0005
  apiStateOpen: "true"   apiStateClose: "true"
  ```
  Field en (S1, contracts endpoint): `tradeMinQuantity` = `The minimum trading unit(COIN)`; `tradeMinUSDT` = `The minimum trading unit(USDT)`.
- **Min-size / precision errors** (S2): `101202` `Order value is below the contract minimum. Increase the order value; query contract info for the minimum.` · `110402` `Order price is invalid - must be greater than the minimum price.` · `110422` `The order size is below the minimum per-order requirement.` · `110425` `Order size does not meet the contract precision or step size requirement.` · `101485` `The closing order size is below the minimum. Increase the closing size.` · `101400` (params incl. `Order amount or quantity below minimum`, `Duplicate clientOrderID`).
- **Position-size limits** (S11/S12): tiered-by-leverage position limits; KYC: `users who have not completed KYC verification will have a maximum leverage limit of 5X and a maximum position limit of 2,000 USDT for some underlying assets`; aggregate position per contract capped as a `predetermined percentage of the total open interest` → over-limit `system will automatically reject orders for new positions`. Worked example (S12): BTC/USDT Perp `10x leverage … maximum position limit of 20,000,000 USDT`; `Perpetual Futures Position Value = Position Size * Mark Price`; `Perpetual Futures Limit Order Value = Order Price * Order Amount`. Current per-symbol numbers live only on the JS-rendered rules page (S14) — **live per-symbol values: `UNVERIFIED_FROM_OFFICIAL_DOCS`** (endpoint `quote/contracts` is the machine-readable alternative).

**(c) Sources:** S1, S2, S3, S4, S10, S11, S12, S14.
**(d)** Cancel = `DELETE /openApi/swap/v2/trade/order`; atomic cancel+replace = v1 `cancelReplace` (STOP_ON_FAILURE/ALLOW_FAILURE, `newOrderResponse` returns everything incl. TP/SL); modify = v1 `amend`; order/TP-SL counts capped (futures numeric max unpublished), cancel-rate>99% triggers 10-min buy freeze; min qty/notional and precision come from `quote/contracts`.

---

## Area 7 — Close entire position vs close by quantity

**(a) Endpoints/fields**
- `closePosition` param on `POST /openApi/swap/v2/trade/order` — whole-position close-on-trigger.
- `POST /openApi/swap/v2/trade/closeAllPositions` — one-click flatten (all symbols or one `symbol`).
- Quantity close: place an order with `side` opposite to the position side (`side=SELL & positionSide=LONG` to close longs; `side=BUY & positionSide=SHORT` to close shorts), sized by `quantity`, and (`reduceOnly` in one-way mode).
- `POST /openApi/swap/v2/trade/positionMargin` (`rate 2/s`) — isolated-margin increase/decrease: `type` = `adjustment direction 1: increase isolated margin, 2: decrease isolated margin`; `positionSide`: `only LONG or SHORT can be selected`; `positionId`: `if it is filled, the system will use the positionId first`; description: `Adjust the isolated margin funds for the positions in the isolated position mode.`

**(b) Exact quotes/semantics**
- Whole-position trigger close (`closePosition`): `true, false; closes the entire position after triggering and supports only STOP_MARKET and TAKE_PROFIT_MARKET. Even when set to true, the current endpoint still requires quantity and stopPrice. It has a reduce-only effect and must not be used with reduceOnly.` → appears in responses as `closePosition` `Whether to close the entire position`.
- One-click all-positions (`closeAllPositions`): `symbol` optional (`Trading pair, for example: BTC-USDT, please use capital letters.`); response `success` = `Multiple order numbers generated by all one-click liquidation` (`LIST<int64>`), `failed` = `the order number of the failed position closing`. History flag `positionHistory.closeAllPositions` = `All positions closed` distinguishes flatten-closes.
- Quantity close constraints: `quantity` = `Order quantity in contract coin units`; `110203` `Available amount for closing is insufficient. Reduce closing quantity or wait for pending orders to fill.`; `101205` / `109420` no-position errors; separate-isolated close needs `positionId`.
- Product behavior of close-everything (S9): `Once either the TP or SL is triggered, the system executes a Market Order for 100% of the remaining position, immediately canceling the opposing side to prevent accidental reverse positions.`

**(c) Sources:** S1, S2, S9.
**(d)** Two official mechanisms: trigger-based whole-position close (`closePosition=true` on STOP_MARKET/TAKE_PROFIT_MARKET, still submits qty as validation) and `closeAllPositions` flatten (returns per-symbol success/failed order-id lists); granular closes are normal `side`+`positionSide`+`quantity` orders (reduceOnly in one-way), with `110203` enforce max closeable.

---

## Gaps / explicit UNVERIFIED_FROM_OFFICIAL_DOCS

1. Numeric max number of simultaneous open (pending) orders per symbol/account for USDT-M futures — only error `101419` confirms a cap; no figure published in S1–S14.
2. Whether **API-created** TP/SL orders are automatically restructured (resized) after a manual partial close — product docs describe auto-reduce/cancel of remaining set amounts (S6/S7/S9), but no API-contract statement; engine should not assume API TP/SL auto-resize.
3. Live per-symbol position-max / max-order values — the trading-rules page (S14) is JS-rendered and returned no table; use `GET /openApi/swap/v2/quote/contracts` (S3) + error codes.
4. BingX "maximum order notional / price deviation" per order in USDT — only 10%-band (limit) and 2%-protection (market) product rules confirmed (S4); no API-side numeric constants.
5. `cancelAllAfter` bundle example text says "spot pending orders" inside the futures `swap/v2` endpoint — doc copy-paste inconsistency (behavior text itself is futures-context batch-cancel).