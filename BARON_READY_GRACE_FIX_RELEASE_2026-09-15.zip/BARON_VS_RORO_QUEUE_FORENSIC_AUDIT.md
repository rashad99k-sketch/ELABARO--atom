# BARON vs RORO — Forensic Queue-to-Execution Audit (READ-ONLY)

> **إخلاء مسؤولية (READ-ONLY):** لم يُغيّر هذا التقرير أي ملف أو إعداد أو بوابة أو استراتيجية أو الجدول Queue أو Zone/OB Judge أو Profit-Engine أو LiveTradeManager أو Portfolio أو Roro. لا فكرة إصلاح مقترحة هنا — تنتهي هذه الوثيقة بعبارة **"FIX SHOULD BE DISCUSSED SEPARATELY"**.

> تصنيف كل معلومة: **[LIVE-REPORTED]** = من لوحة المستخدم الحية. **[CODE-VERIFIED]** = من كود العمل (canonical = جذر الريبو). **[LOCAL-ARTIFACT]** = محلي/اختبار/تقارير سابقة — ليست دليلاً حيّاً. **[NOT AVAILABLE]** = لا وصول له (لا URL/JSON حي). لا يُئوَّل أي سجل محلي إلى دليل LIVE.

> **LIVE SNAPSHOT (المستخدم، أحدث لحظة):** Queue Total=**15**، Ready=**1** (Best Score≈**71.4**)، Waiting Trigger=**1**، Good Zone=**12**، Returned=**1**، Executed=**0**.
> ملاحظة: snapshot سابقة كانت Ready=**0** — أي أنه **أول READY حي-Verified** وصل، وهو ما يحوِّل فرضية التقرير السابق إلى دليل مباشر.

---

## A. EXECUTIVE VERDICT (الحكم التنفيذي)

**نعم — BARON يجد الفرص (طابور ممتلئ 15/15 وREADY حقيقي بدرجة 71.4 مع `ready_blocker=NONE`) لكنه يقتلها قبل التنفيذ.**

- السبب المتحقق الأول: **`QUEUE_MIN_READY_SCORE` (افتراضي 75) يرفض مَن اكتمل READY تحته** — `core/runtime.py:360` — بينما حد READY الفعلي للفئة **68–70** (`core/engine.py:16121-16123` عبر `AssetBehaviorProfile.entry_config.ready_score: 2781-2786`).
- المرشح READY@71.4 عَبَر **الكل** بوابات التأهيل (Confirmation+Trigger+ADX+ATOM+Score+Window+Evidence) ثم يُرفض في كل tick عند بوابة التنفيذ 360 دون أي حدث journal (فقط عدَّاد `ready_score_below_min`). هذا هو نموذج "مرشح يعبر بوابة ثم يُقتل بعده" بشكل حرفي.
- **المقياس الحاسم الذي يجب جلبه** لإغلاق الثغرة: `/data` → `queue.gate_stats` + `pipeline.execution` + قيمة `QUEUE_MIN_READY_SCORE` الحية (الأخيرتان **NOT AVAILABLE** حاليّاً). مع الموجود نقدّر الثقة ≈ **90%** على السبب الأول.

## B. ACTUAL BARON CALL CHAIN (سلسلة الاستدعاء الفعلية — CODE-VERIFIED)

| # | المرحلة | الملف:الوظيفة | الشرط | المخرج | التالي |
|---|---------|----------------|-------|--------|--------|
| 1 | Universe | `build_40_symbol_universe()` (Roro 9150 / parallel in BARON) | — | قائمة 40-50 | Watchlist |
| 2 | Watchlist/Radar | `deep_scanner.py` counters (225/344/597/726/1526) | ≥threshold | `pipeline.watchlist/radar` | تحليل عميق |
| 3 | Institutional bridge | `deep_scanner.py:_institutional_bridge` (1412) — **fix 5d26b69** | تسجيل يومي | تأهيل `institutional_prepared`/A-GRADE | promote |
| 4 | Promotion إلى الطابور | `scanner.py:promote_to_queue` (1074-1307) | محلّل + ≥عمق-OHLCV 30 + غير موجود أصلاناً في الطابور | `pipeline.promotion` dominates (سيلاني) | `add_candidate` |
| 5 | Re-eval دورية | `queue.re_evaluate_all` كل 5s (`QUEUE_RE_EVAL_INTERVAL=5`) | `df≥30` | zone_lifecycle (stale/invalid) | `_update_state` |
| 6 | **بوابات READY** | `engine.py:_update_state` (16104-16262) | confirmation≥min(2 أو 1 PREPARED/A) **و** trigger مؤكد **و** ADX band **و** ATOM (إن توفّر) **و** score ≥ class ready (68-70) **و** entry window **و** evidence OK **و** maturity (خارج افتراضياً `QUEUE_MATURITY_HARD_GATE=0`) | **READY** (gate_stats.ready+=1; journal `QUEUE READY`) | get_best_candidate |
| 7 | **بوابات التنفيذ** | `runtime.py:_execute_ready_queue_candidate` (312-462) | kill_switch(338) ⇒ slots(345) ⇒ **READY فقط أو fallback** ⇒ **[360] priority < QUEUE_MIN_READY_SCORE(75) ⇒ `ready_score_below_min`** ⇒ news_risk≥80(372) ⇒ ALLOCATOR(410-415) ⇒ `PORTFOLIO.open_candidate`(436) | `EXECUTED`(450) أو `open_candidate_failed`(459) | execute_entry |
| 8 | قاضية الأمر | `engine.py:execute_entry` (8447-8586) | OHLCV valid ⇒ SESSION (اختياري) ⇒ **ADX band من جديد (8532)** ⇒ liquidity ctx (8554-8566) ⇒ sweep authenticity (8567-8578) | Order | بدء إدارة الصفقة |

- أبرز ما في السلسلة: **فجوة 68–70 بين READY و75 في خطوة 7**؛ و**تكرار بوابة ADX** في 6 و8؛ ووجود `get_best_candidate` **fallback** (`engine.py:16343-16361`) يعرض مرشح WAITING_TRIGGER ذا trigger مؤكد **بدون** قاع 75 أصلاً (تناقض معكوس — انظر H).
- `PORTFOLIO.open_candidate` كائن واحد لكل توزيع (manager.py)؛ التنفيذ لا يتم من scanner إطلاقاً (بنية معمارية، ARCHITECTURE.md:61).

## C. ACTUAL RORO CALL CHAIN (سلسلة Roro الفعلية — CODE-VERIFIED من `archive/source_supplied_roro.py`)

```
global_discovery_scan
  → (كل 5 دقائق) WatchlistPriorityManager.update_priorities
  → promote_to_queue (7267): أفضل 30 من watchlist/rf/scanner_v2، OHLCV≥30، priority=intent_score (7336)
  → queue.re_evaluate_all (6684) كل 5s:
        df<30 ⇒ invalidate | extended>1.5ATR ⇒ return | OB broken>0.8ATR ⇒ invalidate
        final_zone_score + trigger_state ⇒ _update_state (7057):
             score≥85 و trigger∈{MSS_CONFIRMED,LIQUIDITY_SWEEP,BOS_CONFIRMED,CHOCH_CONFIRMED} ⇒ READY
             else score≥70 ⇒ WAITING_TRIGGER | ≥55 ⇒ GOOD_ZONE | <55 ⇒ WATCHLIST | priority<30 ⇒ return
        cleanup (7156): انتهاء 1h (score≥40 ⇒ return-to-watchlist وإلا حذف)
  → process_queue_entry (7340):
        best = get_best_candidate() (READY فقط، أعلى priority)
        priority < 80 ⇒ return (بصمت)
        execute_entry (8862) مباشرة — لا allocator، لا news، لا PortfolioManager، لا Zone/OB Judge
  → تنفيذ (8862): position مفتوحة؟ تخطٍّ | sizing | order
```

- **مسار قديم آخر** `monitor_watchlist` (5738-5792) وحده يستخدم `check_institutional_entry` (5559): intent ≥ 75، sweep، zone tap (strength≥5 و distance<0.3%)، MSS/CHoCH، rejection/displacement، volume، ADX≥18 صاعد، RF+مسافة≤0.003 — ثم `execute_entry(score=85)` (5756).
- **نقطة جوهرية:** حزمة بوابات Roro "الغنية" تعيش في المسار القديم فقط؛ مسار الطابور عند Roro **رَشِيق**: READY(zone≥85+trigger) ثم ≥80 ثم أمر. لا Confirmation-chain، لا ATOM، لا News، لا Allocator.

## D. 15-CANDIDATE FORENSIC TABLE (جدول المرشحين)

**NOT AVAILABLE** — لم يصل أي `queue.candidates[]`/JSON/URL حيّ. لا أسمِّي رموزاً حية.

التوزيع الحالي من اللقطة الحية (LIVE-REPORTED):
| state | count | الدلالة (CODE-VERIFIED) |
|-------|-------|--------------------------|
| READY | 1 (≈71.4, ready_blocker=NONE) | عَبَر كل بوابات التأهيل — يُقتل عند 360 (75) |
| WAITING_TRIGGER | 1 | trigger غير مؤكد أو confirmations ناقصة |
| GOOD_ZONE | 12 | score 55–69 أو تحت READY gates (blocker CONFIRMATION/TRIGGER/READY_SCORE_FLOOR…) |
| RETURNED_WATCHLIST | 1 | جاهز للـ cleanup (extended/stale/expired) |
| EXECUTED | 0 | — |

القائمة المطلوبة لكل صف (لقيتُها في `to_dict()` engine.py:13246-13319): SYMBOL، SIDE، SCORE(priority/final_zone)، STATE، READY STATUS(ready_blocker)، READY REQUIRED SCORE(**غير معرّضةن — أشتقّها: class ready_score**)، QUEUE MIN READY SCORE(env — لا يظهر في payload)، TRIGGER(trigger_state)، ZONE(zone_state/zone_info)، OB(ob_score/ob_grade)، ADX(latest_adx/bounds)، LIQUIDITY(liquidity_state/liquidity_evidence)، CONFIRMATION(confirmation_count/state)، ATOM(**ليس في payload**)، ENTRY WINDOW(zone_state)، AGE/EXPIRY(**ليسا في payload**؛ مشتقّان من added_at/cleanup 1h)، FINAL BLOCKER(ready_blocker/ready_blocker_reasons + gate_status).

**للرفع إلى LIVE:** انسخ `GET /data` → `queue.candidates[]` + `GET /queue` → `candidates[ALL]` + `gate_stats` ثم ألصقها هنا.

## E. FIRST BLOCKING GATE PER SYMBOL

غير متاح لكل رمز حي. لكن بترتيب الكود (engine.py:16182-16213) الأوّلي: **CONFIRMATION > TRIGGER > ADX > ATOM_HARD_REJECT > ATOM > READY_SCORE_FLOOR > ZONE_WINDOW > EVIDENCE** ثم بعد READY بوابة تنفيذ 360 (75) ثم News/Allocator/ADX_REJECT.

الخلاصة التجميعية للـ 15 الحي: 12 عالقون في READY-funnel، 1 WAITING_TRIGGER، 1 READY — **والمرشح READY@71.4 هو المثال النصي لمطلبك: "عبر بوابة ثم قُتل لاحقاً"** (عبر التأهيل كاملاً ثم قُتل عند 360).

## F. READY vs EXECUTION THRESHOLD AUDIT (تدقيق تناقض الحدود)

| الحد | القيمة | المصدر (CODE-VERIFIED) |
|------|--------|------------------------|
| READY score class | CRYPTO=68 | INDEX=68 | STOCK=67 | GOLD=70 | OIL=70 | NEWS=70 | `ENTRY_PROFILES` engine.py:2781-2786 → `_update_state` 16121-16123 |
| EXECUTION queue min | **75 افتراضياً** (env `QUEUE_MIN_READY_SCORE`) | runtime.py:360 |
| تعليق الكود نفسه | "READY and EXECUTION both at 75 — unified" | runtime.py:350-355 |
| تعليق engine | "class ready_score, **default 75** — two-stage intentional" | engine.py:16115-16119 |

- **READY=True (71.4) و EXECUTABLE=False (<75) = CONFIRMED:** لا تناقض في الكود بل **انحراف تنفيذي**: التصميم كان حداً موحّداً 75 (التعليقان)، لكن الـ ready_score الفعلية للفئة 68–70، والتنفيذ بقي على 75. القصد: **تصميم مرحلتين مقصود (PASS 65 → READY)**؛ النتيجة: **تناقض غير مقصود بين بوابة التأهيل (68-70) وبوابة التنفيذ (75)** — «التصميم مقصود، الانحراف حادث».
- دليل إضافي على عدم كون 75 هو قيمة READY الفعلية على الحيّ: وصول شارة `READY` نفسها على 71.4 يستحيل لو كانت ready_required=75 (لكان blocker=READY_SCORE_FLOOR). إذن الحيّ يستخدم فعلاً 68-70.
- تناقض معكوس: fallback `get_best_candidate` (16343-16361) يسمح بتنفيذ مرشح WAITING_TRIGGER بtrigger مؤكد **بدون أي قاع** (runtime.py:356 `is_ready=False` ⇒ 75 لا يُفحص) — النظام لا يطبق القاع لا على READY<75 ولا على fallback بالتساوي.

## G. BARON vs RORO GATE MATRIX

| Gate | Roro (queue-path | legacy) | BARON | Roro threshold | BARON threshold | Mandatory? | Duplicate? | Impact |
|------|--------------------------|-------|----------------|-----------------|------------|------------|--------|
| Discovery/Universe | ✓ | ✓ | top-30 → 40-50 | 40-50 | نعم | لا | funnel head |
| Institutional Intent | legacy only | ✓ (prepared path) | intent≥75 (legacy) / prepared-fast | `institutional_prepared`/A | legacy نعم | جزئي | يعمّق BARON |
| Zone tap/proximity | legacy | ✓ (zone_state) | strength≥5 & 0.3% (legacy) | ENTRY_WINDOW/RETEST/ACTIVE + 1.5ATR | نعم | لا | — |
| OB quality | ✓ (score فقط) | ✓ (score) | — | ob_score في final | ضمن score | لا | — |
| Liquidity/Sweep | ✓ في trigger | ✓ في trigger | sweep في trigger_state | نفس | نعم | لا | — |
| MSS/CHoCH/BOS | ✓ trigger | ✓ trigger | في trigger_state | نفس | نعم | لا | — |
| Rejection/Displacement | ✓ trigger | ✓ trigger | ضمن confirmation events | نفس | نعم | جزئي | — |
| Volume | ✓ (score) | ✓ (score) | ضمن evidence | — | لا | لا | — |
| ADX | legacy فقط | **✓ gate (READY + recheck)** | ADX≥18&rising | **class band [16-55]… مرتين** | نعم | **✓ مزدوج** | ADX_REJECT |
| RF + RF distance | ✓ legacy | ✓ evidence | ≤0.003 | evidence/label | legacy نعم | لا | — |
| Anti-chase | ✓ 1.5ATR extension | ✓ 1.5ATR extension | 1.5ATR | 1.5ATR | نعم | لا | — |
| Entry Window | ضمن timing | ✓ zone_state | dist<0.3% (legacy) | zone_state | نعم | لا | — |
| Trigger (confirmed) | ✓ READY | ✓ READY | always | always | نعم | لا | — |
| **Confirmation chain** | **✗ لا يوجد** | **✓ (2 أو 1)** | — | count≥2/1 | — | **خاص بـ BARON** | الوقود الأكبر |
| ATOM | ✗ | ✓ (إن توفّر) | — | approve&&!reject | عند التوفّر | — | خاص بـ BARON |
| Evidence/narrative | legacy | ✓ label≠INVALID | narrative | label | legacy | لا | — |
| **READY score** | **85** (7057) | **68-70** (16121) | zone≥85 | class | نعم | **السبب** |
| **Queue minimum** | **80** (7340-7352) | **75** (runtime 360) | priority≥80 | priority≥75 | نعم | **✓ فوق READY** | الزومبي |
| Portfolio capacity | ✗ (position واحد) | ✓ 6 سلوت/classes | position واحد | MAX_OPEN=6 | نعم | لا | — |
| Allocator | ✗ | ✓ (410-415) | — | class/direction | نعم | — | خاص بـ BARON |
| News gate | ✗ | ✓ (372) | — | news_risk≥80 | نعم | — | خاص بـ BARON |
| Zone/OB Judge (execute) | ✗ | ✓ ADX+liq+authenticity (8532-8578) | — | نفس band مرتين + ctx | نعم | **✓ مزدوج ADX** | آخر شبك |
| TTL expiry | ✓ 1h | ✓ 1h | 3600s | 3600s | نعم | لا | يقتل "الصحيح" |

## H. DUPLICATE GATE AUDIT (البوابات المكررة)

1. **READY floor (68-70) vs Execution floor (75)** — نفس المتغير (`priority_score==final_zone_score`) بحدين مختلفين؛ مقصود التوحيد عند 75 (تعليق runtime.py:350) لكنه لم يتحقق. **أخطر تكرار = تناقض فعلي.**
2. **ADX مزدوج** — READY (engine.py:16160) و execute_entry (8532) بنفس الـ band للفئة؛ أي انحراف بلحظات يفصل بينهما ينتج `ADX_REJECT` بلا حاجة لبوابة جديدة.
3. **Liquidity/sweep مزدوج** — trigger (READY) و liquapproval (8540-8578) ما زالا يُفحصا ثانية في التنفيذ (`detect_liquidity_context` + sweep authenticity).
4. **تثبيت Trigger** — مؤكد في READY، ومتطلب في fallback (`get_best_candidate` 16356-16357) أي نفس الشرط مرتين.
5. **Roro**: لا تكرار — مسار الطابور عنده حدّ واحد 85 (= READY) ثم 80، والـ legacy chain منفصلة. (الـ 80 و85 لغزان لـ Roro: اللحظةُ بعد re-eval هي خوان zone=priority، فـ 85>80 يجعل قاع 80 تافهاً.)

## I. QUEUE LIFECYCLE / EXPIRY AUDIT

| خاصية | BARON (CODE-VERIFIED) | Roro (CODE-VERIFIED) |
|-------|----------------------|----------------------|
| TTL/Expiry | 3600s (`cleanup` engine.py:16396؛ expired≥40 ⇒ return) | 3600s (7163) |
| Re-eval interval | 5s (`QUEUE_RE_EVAL_INTERVAL=5`) | 5s (918) |
| Promote interval | 20s watchlist service / gate | 30s (919) |
| Trigger lifetime | حالة trigger تُحمل طالما المرشح حي | نفسه |
| Zone stale | `zone_stale`/`zone_invalidated` counters | extension/OBB fight |
| أقصى حجم | 15 (`QUEUE_MAX_SIZE`) | 15 (917) |

- **هل "setup صحيح" يموت قبل trigger؟** نعم في كليهما (عمر 1h)، لكن في BARON يموت أيضاً وهو **READY** (68-74.99) — نموذج زومبي يعيد التدوير كل ساعة؛ والرقم `Promoted=7888` (تراكمي) متوافق مع هذا التبديل اليومي وليس مع فرص فريدة (الدخول في الطابور يمنع التكرار داخل اللحظة الزمنية الواحدة؛ التكرار يأتي بعد return+إعادة promotion).
- **هل Roro عنده نفس المشكلة؟** عنده عمر 1h أيضاً، لكن **لا ثغرة READY-زومبي**: عنده READY=85=قابل للتنفيذ، فمن بلغ READY يتنفّذ فوراً. خسارته الصامتة: المرشحون 80-84 يموتون بالساعة بلا تنفيذ (ولكن بلا تناقض داخلي).

## J. BOTTLENECK RANKING (الجسم التنفيذي الحيّ)

القمع بين الـ 15 الحاليين فقط (فريد، من اللقطة):
- GOOD_ZONE 12 (80%) ⇒ عالقون عند بوابات READY. WAITING_TRIGGER 1 ⇒ trigger/confirmations ناقصة.
- **READY 1 (6.7%) ⇒ 0% تنفيذ.** لذلك: **أعنق نقطة (نسبة للحي) = الانتقال READY→EXECUTION**.
- تنبيه: `Promoted=7888` و`Re-evaluated=442` و`gate_stats` كلها **counters تراكمية** — لا تُعد فريداً؛ لا نستطيع إنتاج funnels فريدة فوق الطابور بدون `queue.candidates[]` حي (**NOT AVAILABLE**).

## K. COUNTERFACTUAL RESULTS (المحاكاة الثابتة على مسار الكود؛ LOCAL-ARTIFACT مؤيَّد بـ `tests/test_pipeline_lifecycle_runtime.py`)

| Treat | النتيجة المتوقعة | دليل |
|-------|------------------|------|
| `QUEUE_MIN_READY_SCORE`→68/70 أو إزالته | READY@71.4 يعبر 360 ⇒ News(≤80) ⇒ Allocator ⇒ `open_candidate` ⇒ execute_entry (ADX سليمة من READY) ⇒ **احتمال تنفيذ مرتفع لأول صفقة** | 360 ثم قصّة المسار 349-458 |
| رفع READY floor إلى 75 | 71.4 لا يصبح READY أبداً (blocker READY_SCORE_FLOOR)؛ نفس الصفر؛ بلا زومبي؛ counter = `no_ready_candidate` | 16199-16207 |
| إزالة Confirmation chain (نمط Roro) | READY مبكر على trigger فقط؛ **بقاع 75 لا تغيير** (71.4 <75) | 16146/16244 |
| إزالة ATOM | لا تغيير إن كان module غائباً (gate auto-PASS 16153-16155)؛ إن حضراً فقد أضاف عوائق إضافية | 16148-16155 |
| إزالة Zone/OB Judge (ADX+liquidity في execute_entry) | يعطّل تكرار البوابة، لكن **600 قبلها عند 75** ⇒ لا أثر حتى يُحلّ القاع | 8532-8578 |
| **الخلاصة** | **القاع 75 يهيمن على كل السيناريوهات** — أي إصلاح قبل حلّه صفر الأثر. | — |

## L. ROOT CAUSE (ترتيب الأسباب)

1. **[CODE+LIVE ، ثقة ≈90%] قاع التنفيذ 75 ضد حد READY 68-70**: READY@71.4 مكتمل، يُرفض في runtime.py:360 كل tick، بدون أي حدث journal (فقط counter `ready_score_below_min` + `last_outcome`). نوعه: **mismatch (انحراف حدود، تصميم مقصود/تنفيذ غير مقصود)**.
2. **[CODE ، ثقة ≈75%] عُطل المراقبة**: `ready_score_below_min` **لا يسجّل** في journal/gate_feed ولا يظهر في لوحة `/data` الرئيسية سوى counter/`last_outcome` — فالقاتل خفي، ولا يُعرف سبب استمرار الصفر.
3. **[NOT AVAILABLE ، ثقة 40-60%] بوابات ثانوية حية** (News/Allocator/ADX_REJECT/LIQUIDITY_REJECT): لا يمكن ترتيبها دون `pipeline.execution` + سجل EXECUTION live. ترتيب الكود يجعلها غير مسؤولة عن الزومبي الحالي (375/415/436 بعد 360).

## M. WHAT IS NOT THE PROBLEM

- **البنية Bridge/registrar** — مُصلَح (الطابور ممتلئ 15).
- **Discovery/Promotion** — 15 في الطابور؛ عداد high ناتج عن تناوب.
- **عمق البيانات** — للحصول على READY يحتاج ≥30-bar، وقد تحقق.
- **الحدّ الأقصى (=الطابور ممتلئ)** — غياب الفرص، لا غياب القبول.
- **شرط Trigger للـ READY** — READY يعني trigger مؤكد + confirmations (window مغلق فقط عند بوابات التأهيل).
- **ATOM كحاجز اليوم** — auto-PASS عند غياب module.
- **وجود READY ذاته** — بات مثبتاً حيّاً (1×71.4).
- **Kill switch / portfolio ممتلئ بالكامل** — كان ليعود `kill_switch` أو `no_slots` (لم يحدث لنا منهما دليل؛ **القيم الحية NOT AVAILABLE**).
- **عمر 1h وحده** — شريك لـ Roro؛ ليس الجذر.

## N. FINAL VERDICT (جملة واحدة)

**نعم — BARON لا يفتقد الفرص؛ يجدها ثم يقتلها قبل التنفيذ: طابور ممتلئ (15) و READY حقيقي (71.4) مع `ready_blocker=NONE` لكنه يُرفض حتماً عند بوابة `QUEUE_MIN_READY_SCORE=75` (runtime.py:360) بينما حد READY الفعلي للفئة 68–70 — أي الصفر ليس "فراغ فرص" بل «بوابة تنفيذ متناقضة مع بوابة التأهيل».**

*(الرد النهائي لمن يقرأ بالعربي: YES + evidence أعلاه.)*

## O. EVIDENCE APPENDIX (معجم الأدلة والخطوات للرفع من NOT AVAILABLE→LIVE)

| معلومة | التصنيف | المصدر |
|--------|---------|--------|
| Queue 15/15، READY 1@71.4، WT 1، GZ 12، Ret 1، Exe 0 | LIVE-REPORTED | لوحة المستخدم |
| READY floor 68-70 | CODE-VERIFIED | engine.py 16121-16123، 2781-2786 |
| Execution floor 75 | CODE-VERIFIED | runtime.py:360 (env default) |
| ترتيب التنفيذ 360 قبل News/Allocator/Open | CODE-VERIFIED | runtime.py 312-462 |
| fallback بدون قاع | CODE-VERIFIED | engine.py 16343-16361 + runtime.py 350-356 |
| reset counter/journal غياب | CODE-VERIFIED | runtime.py 322-362؛ record_gate_event engine.py 13060 |
| Roro READY=85 / floor=80 / legacy=75+/sweep/tap | CODE-VERIFIED | archive/source_supplied_roro.py 7057،7340،5559 |
| TTL 1h كليهما | CODE-VERIFIED | engine.py 16396؛ roro 7163 |
| مسار A-GRADE الميّت (roro_signal=False) | CODE-VERIFIED | deep_scanner.py:1115 |
| `forensic_pipeline.py` (أداة محلية: يتطابق مع 312 لكنه يتوقّف قبل الطلب؛ يذكر "80 (from .env.example)" بينما `.env.example` الحالي بلا `QUEUE_MIN_READY_SCORE` ⇒ default 75) | LOCAL-ARTIFACT | forensic_pipeline.py:52/593؛ .env.example |
| اختبار READY→executed/ready_score_below_min بالـ runtime الحقيقي | LOCAL-ARTIFACT | tests/test_pipeline_lifecycle_runtime.py |
| نسخ `BARON/` و`SAR_ATOM/` | LOCAL-ARTIFACT (قديمة؛ تحمل نفس bug 75) | BARON/core/runtime.py:314؛ SAR_ATOM/core/runtime.py:266 |
| أسماء الرموز الحية + القيم env الحية (QUEUE_MIN_READY_SCORE, pipeline.execution, gate_stats) | **NOT AVAILABLE** | يحتاج JSON/URL |

**Runbook لرفع الـ NOT AVAILABLE (لا يُعدّل شيئاً):**
1. `/data` → انسخ `queue` (طلبات) + `pipeline` (execution/gate_stats).
2. `/queue` → انسخ `candidates[ALL]`.
3. Env (Railway settings) → `QUEUE_MIN_READY_SCORE`, `QUEUE_MIN_READY_SCORE` الافتراضي 75، `NEWS_RISK_BLOCK`, `MAX_OPEN_POSITIONS`, `PAPER_MODE`.
4. سجلات runtime: `[QUEUE]*EXECUTION/READY`, `[ENTRY]*REJECT`, `[PORTFOLIO]*reject`, عدادات `exec_pipe`.

---

> **فكّر في الحل بعد هذه الوثيقة ⇐ FIX SHOULD BE DISCUSSED SEPARATELY.**