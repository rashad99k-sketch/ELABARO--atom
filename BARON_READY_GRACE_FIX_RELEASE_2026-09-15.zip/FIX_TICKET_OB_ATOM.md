# Fix Ticket — البنية التحتية لتقييم OB و ATOM (مستند توصية فقط — لا تعديل)

> النطاق: توصية مطوّرة، صفر تعديل على الكود في هذه المرحلة. كل الأسطر/القيم مستخرجة من المشروع الحالي
> (`core/engine.py`, `portfolio/manager.py`, `scanner/deep_scanner.py`) ومساندة بتحقيقات قراءة-فقط.
> أدلة قياسية: `ob_class_events.csv` (5434 حدث)، `ob35_sweep_out.txt` (حساسية النافذة).

---

## ملخص تنفيذي
النظام يقيّم OB/ATOM للأسهم والمؤشرات بمنظور «كريبتو» كامل:
1. **تصنيف خاطئ**: كل NCSK\*/NCSI\*/NCCO\* يصبح CRYPTO ⇒ إنفاذ ملف CRYPTO بالكامل (floor 68، ADX 16-55،
   `OB_UNIFIED` بدل `OB_ASSET.STOCK`).
2. **طبقة أدلة معطّلة**: نداء `scanner/deep_scanner.py:1022` إلى `radar._select_strong_ob` يستهدف طريقة غير موجودة
   على `InstitutionalRadar` ⇒ `AttributeError` يُبتلع ⇒ السجل النسجي `institutional_ob` فارغ دائمًا.
3. **نافذة بحث ضيقة وغير قابلة للتفاوض**: `ob_search_bars=35` (~8.75h) بلا مفتاح env، وهي سبب قابل للقياس لـ
   fallback `OB NONE score=25`.

النصفين معًا يفسران: «Ready=0» و «A-Grade=0» و «كل كيو OB NONE 25» أثناء اللقطة المباشرة — دون أن تعكس حقيقة
السوق (الأسهم تُنتج OB حقيقي >40 في ~49% من النوافذ، كما قيس المسح).

---

## T-1 — تصنيف الفئات: `resolve_asset_class` ⇒ CRYPTO دائمًا للمؤشرات NCS\*/NCCO\*

**الموقع**:
- `portfolio/manager.py:58` `PortfolioManager._asset_class(symbol)` — لا يلتقط أسلاف NCSK/NCSI/NCCO؛
  يعتمد على `stock_hints` بتطابق حرفي (AAPL، TSLA…) ومتنبّبات (SP500، GOLD، WTI…).
- `core/engine.py:2788` `AssetBehaviorProfile.resolve_asset_class(symbol)` — يتفقد `PortfolioManager._asset_class`
  أولًا، وكل ما يعود غير-معدود CRYPTO **مشروع** (لأن `CRYPTO ∈ cls.DEFAULT`) فيعاد فورًا. قوائم الفحص
  الاحتياطية (GOLD/OIL/INDEX/ركائز AAPL…) لا تُستدعى أبدًا.

**الأثر الكمّي (مقيس في اللقطة)**:
- بوابة READY floor = **68** (= ready_score ملف CRYPTO عند `engine.py:2730`) على كل الفئات؛
  ملف STOCK الأصيل (67) لا يُستخدم.
- غرض OB = `OB_UNIFIED` (engine.py:2690: `ob_min_disp_atr 0.6 / ob_search_bars 35 / fresh (10,20,40)`)
  لأنه `OB_ASSET_TUNING` مغلق أساسًا — ومهما فُتّح، التصنيف=CRYPTO يوجّه إلى `OB_ASSET.CRYPTO` لا STOCK.
- `OB_ASSET.STOCK` (engine.py:2711: search 25, disp 1.0, fresh (5,10,20)) **لا يمكن بلوغه أبدًا**.

**الإصلاح المقترح** (للتنفيذ يدويًا لاحقًا):
1. أ. في `_asset_class`: أضف قواعد بادئة قبل الرجوع 👈 الأكثر أولوية:
   - `NCSK*` → STOCK، `NCSI*` → INDEX، `NCCO*` → (GOLD/OIL حسب اللاحقة: GOLD/WTI),
2. ب. (احتياطي) في `resolve_asset_class`: عند `"NCSK" in up` إلخ قبل النداء أو بصفته سطرًا بديلًا.
3. حافظ على التوافق: يجب أن يُعيد `NCSKTSLA2USD` → STOCK مع بقاء `TSLA` حرفي → STOCK (لا تغيّر سلوك).

**معيار القبول**: `resolve_asset_class('NCSKDELL2USD/USDT:USDT') == 'STOCK'`، و `entry_config('NCSK…')['ready_score'] == 67`.

---

## T-2 — طبقة الأدلة المعطّلة: `scanner/deep_scanner.py:1022`

**الموقع**: `scanner/deep_scanner.py:1014-1060`.
**السبب الجذري**: الكلاس `InstitutionalRadar` (engine.py:13051) **لا يملك**
`_select_strong_ob/_evaluate_liquidity/_evaluate_structure`؛ الثلاثة طرق على **`ExecutionQueue`**:
- `_evaluate_liquidity(self, df, side, atr)` — engine.py:15005
- `_evaluate_structure(self, df, side)` — engine.py:15106
- `_select_strong_ob(self, df, side, atr, cfg=None)` — engine.py:15663

النداء `radar._select_strong_ob(df, _side, atr_i)` يرمي `AttributeError` في كل مرة، ويُبتلع بالـ
`try/except` (deep_scanner.py:1014) ⇒ `institutional_ob = {"BUY":{}, "SELL":{}}` دائمًا.

**الأثر**: طبقة «الدليل النسجي للرادار» في سجل الـ watchlist معدومة؛ ساهمت في:
- «Institutional Zone Analysis: MEDIUM» لجميع الـ 38 في اللقطة،
- بلوغ «A-Grade Ready = 0» («أّتى القناة لا تملك أبدًا strong_ob»).

> ملاحظة: بوابة READY/atom لا تعتمد على هذه الطبقة (تستخدم `ExecutionQueue` مباشرة) — لذا ليس هذا سبب الـ Reject، بل
> سبب فقدان *شهادة* A-Grade على مستوى الرادار.

**الإصلاح المقترح** (إحدى السبلتين):
1. أ. قم بتغييرات النداء في `deep_scanner.py:1022` إلى طريق `ExecutionQueue`:
   `E.queue._select_strong_ob(df, _side, atr_i)` (+ `_evaluate_liquidity`, `_evaluate_structure`) — مع تمرير
   `cfg=E.AssetBehaviorProfile.ob_config(E.AssetBehaviorProfile.resolve_asset_class(symbol))`؛
   `cfg=None` على أي حال يعيد القيم الافتراضية 35/0.6 (engine.py:14801-14802) — لذا أصرّ على cfg بعد T-1.
2. ب. أضف `hasattr(radar, "_select_strong_ob")` قبل النداء (حارس دفاعي) — مهما كان السبل.
3. استدراك وثائقي: وسمُ المسؤولية في `deep_scanner.py` (أو docstring `InstitutionalRadar`) ليعكس حقيقة وجود الطريقة على Queue.

**معيار القبول**: بعد الإصلاح، في دورة scan أكبر، تظهر عناصر غير فارغة في `institutional_ob` وصفوف `A-Grade` في
سجل الـ watchlist (تشغيل واحد عبر harness `forensic_trace.py` على نسخة مؤقتة).

---

## T-3 — نافذة البحث السببية `ob_search_bars=35` (≈8.75h) بلا مفتاح تفاوض

**الموقع**: `core/engine.py:2690` (`OB_UNIFIED`)؛ القراءة عند engine.py:14801 (`_evaluate_order_block`,
`default 35`). لا يوجد مفتاح env لإعادة كتابة `ob_search_bars` — فقط `OB_<CLASS>_DISP_ATR` مع تفعيل
`OB_ASSET_TUNING` (والتصنيف يوجّه لـ CRYPTO ولن يصل لـ STOCK أصلاً — أنظر T-1).

**الأثر الكمّي (مقيس، `ob35_sweep_out.txt` — نافذة 35→70→140 على نفس البيانات)**:
| الرمز | FAKE=25 | eob>40 |
|---|---|---|
| SKOSPI12 | 81% → 56% → **16%** | 19% → 41% → **84%** |
| WDAY | 80% → 50% → 20% | 8% → 20% → 22% |
| PAYP | 63% → 32% → 7% | 23% → 48% → 70% |
| RECRUIT | 60% → 32% → 2% | 23% → 37% → 60% |
| MUU2 / DELL2 | 32/12 → 5/5 → **0/0** | 60/70 → 87/82 → 90/85 |

لكن **التجارة مقايضة**:
- `BROKEN` يرتفع بالتوسيع (WDAY 12%→58%)،
- درجة **A/A+ تهبط** (BTC 15→8، GOLD 8→4، OIL 10→7) — لأن نافذة أوسع تكشف OBs أقدم لا تحقق
  `ob_fresh_grade (10,20,40)` ⇒ النافذة تتصرف كمرشّح طزاجة قهري.

**الإصلاح المقترح**:
1. اضغط `ob_search_bars` قابلاً للّه من env مرن مع default يحافظ على السلوك الحالي:
   - `OB_SEARCH_BARS` (عمومي) و/أو `OB_<CLASS>_SEARCH_BARS`،
2. أو اعتمد ملفات OB الفئوية حقيقة: بعد T-1، افحص `OB_ASSET.STOCK (25) / INDEX (30) / GOLD (45) / OIL (40)`
   و»ارفع» search للفئات بطيئة الإيقاع بدل توسيعه لكل شيء.
3. قرار سياسة منفصل: عند التوسيع، إمّا خفّض `ob_fresh_grade` للمؤشر/السهم (T-4) وإمّا اقبل `B` كـ (strong_ob كاف).

**معيار القبول**: بعد T-1+T-3، إعادة `ob_class_stats.py` (نفس العينة) ⇒ FAKE<50% و eob>40>55% للأسهم.

---

## T-4 (اختياري، سياسة لا كود) — ندرة درجة A/A+ في الأسهم
مقيس: A+ **0.2%** / A **1.1%** للأسهم مقابل CRYPTO 2.0%/11.1% (~10×) على نفس المكشّف ونفس النافذة.
النتيجة المنطقية: كآلية `strong_ob = A+ أو A` عمليًا «مغلقةً» للأسهم على 15m مهما أُصلح T-1/T-2.
القرار المتاح: خفض متطلبات الطزاجة للفئات بطيئة الإيقاع، أو اعتماد درجة `B` فوق عتبة، أو تقييد «الغرض»
الشديد (A/A+) بالعمل للأسهم طوعًا. هذا خارج نطاق الكود ويحتاج موافقة.

---

## التوصية بأولوية التنفيذ ومعايير القبول
| الأولوية | العصب | الهدف |
|---|---|---|
| 1 | T-1 (تصنيف) | يفتح ملفات الفئات و floor الصحيح (67) |
| 2 | T-3 (نافذة) | يقضي على FAKE=25 الجبري وإعادة توزيع >40 |
| 3 | T-2 (الرادار) | يعيد طبقة الأدلة وأثر A-Grade للسجل |
| 4 | T-4 (سياسة) | قرار الحوكمة على A/A+ للفئات البطيئة |

**قبول شامل**: إعادة كل المسوحات القياسية (`ob_class_stats` / `ob35_sweep` / `forensic_trace`) بعد كل
إصلاح، ومقارنة بجدول 5434 حدث الحالي.

**ملفات متأثرة محتملة (بدون تعديل الآن)**:
- `portfolio/manager.py:58` (`_asset_class`) — T-1
- `core/engine.py` (`resolve_asset_class` :2788، `OB_UNIFIED` :2690، `OB_ASSET` :2702، `ENTRY_PROFILES` :2729) — T-1/T-3
- `scanner/deep_scanner.py:1014-1060` — T-2
- `core/atom_intelligence.py` (متعلق بـ T-4 فقط) — اختياري

**ردود الفعل الممنوعة**: لا تغيير في هذا المستند في النطاق الحالي؛ التنفيذ بيد المطوّر بعد الموافقة.
المشروع لم يُمسّ — «صفر تعديل» مطبّق.