# BARON — 9-HOUR ZERO-TRADE FORENSIC REPORT

> **هذه العملية تشخيصية فقط: READ-ONLY.** لا توجد أي تعديلات على الشيفرة أو الإعدادات أو أي أوامر
> تنفيذ أو commit/push/deploy. التقرير مبني على القراءة الكاملة للكود + تحليل `runtime/` + `logs/` + git history.
> أي رقم في هذا التقرير إما `CODE-VERIFIED` (موثّق من الكود) أو `LOCAL-ARTIFACT` (من ملفات محلية = محاكاة/تست)
> أو `LIVE-REPORTED` (من شاشة الـ Railway كما وصفها المستخدم). كل رقم مُعلَّم بأي فئة ينتمي؛ لا تخمين.

---

## 1. الهدف / Objective
تحديد — بالأدلة لا بالتخمين — لماذا ركض `BARON` LIVE على Railway حوالي 9 ساعات (من ≈12:07 UTC 2026-09-13 حتى ≈21:07 UTC) بينما لوحة الـ Pipeline تظهر `Executed = 0` و `Ready = 0` بينما `Promoted` و `Re-evaluated` بأرقام كبيرة (`LIVE-REPORTED`).

## 2. المهمة / Mandate
- قراءة الحالة فقط.
- الإجابة المباشرة على 4 أسئلة (لماذا صفر صفقات؟ أقرب الرموز لـ READY ولماذا فشلت؟ أين تُفقد الفرص بالضبط؟ هل المشكلة Strategy/Gate/Pipeline/Data/Runtime؟).
- أعلى 3 أسباب مدعومة بأدلة مع اختبار تفنيد لكل سبب.
- لا اختراع نتائج؛ كل ما لا يمكن إثباته من Railway يُعلن "غير متاح محلياً" مع دليل استخراجه خطوة بخطوة.

## 3. البلاغ الحرج / Chief Complaint
| المقياس | القيمة | الفئة | تفسير العداد (Code-verified) |
|---|---|---|---|
| Universe | (غير محدد) | LIVE-REPORTED | `pipeline.universe` من `DeepScanner.scan` (deep_scanner.py:226) |
| Radar | (غير محدد) | LIVE-REPORTED | `pipeline.radar` من radar cycle (deep_scanner.py:344/726) |
| Watchlist | كبير | LIVE-REPORTED | `pipeline.watchlist.active` (deep_scanner.py:598, 1528) |
| **Promoted** | **7888** | LIVE-REPORTED | تراكمي منذ الإقلاع: `MEMORY['watchlist_queue_promotions']` يزيد عند كل إضافة ناجحة للطابور (scanner.py:1298). **يعيد حساب نفس الرمز مراراً، لا عدد الصفقات المميزة.** |
| In Queue | 15 | LIVE-REPORTED | `queue.get_status().total_candidates` — و 15 = `QUEUE_MAX_SIZE` (engine.py:587) أي الطابور **ممتلئ دائماً**. |
| **Re-evaluated** | **442** | LIVE-REPORTED | مجموع عدادات `gate_stats`: `ready + extended + zone_stale + zone_invalidated + score_too_low + ob_broken + insufficient_data` (dashboard/app.py:871). **يشمل `ready` — فليس كل الـ 442 انعكاس ولا امتداد.** |
| **Ready** | **0** | LIVE-REPORTED | عدد مرشحَي الطابور الحاليين في `ExecutionState.READY` (engine.py:16340). |
| **Executed** | **0** | LIVE-REPORTED | `pipeline.execution.executed` من `_execute_ready_queue_candidate` (runtime.py:450) — لا يزيد إلا عند نجاح `PORTFOLIO.open_candidate(...)`. |
| IZA A-Grade Ready | (يفترض 0) | CODE-VERIFIED | `a_grade_ready` لا يمكن أن يكون True على مسار الـ watchlist لأن `deep_scanner` يكتب `"roro_signal": False` دائماً في كائن الـ analysis (deep_scanner.py:1115)، و`_update_a_grade_status` يطالب بـ `roro=True` (engine.py:13642). كل القبول في الطابور عبر مسار `PREPARED` فقط. |

**الاستنتاج الفوري:** الطابور ممتلئ (15/15)، الـ Promotions تراكمية (تعيد إضافة نفس الرموز)، والـ READY الحالي صفر، والتنفيذ صفر. المشكلة ليست في قبول الطابور (بُني على الـ bridge المُصلَح) بل في التحويل من "في الطابور" إلى "READY" ثم إلى "تنفيذ ناجح".

## 4. القيد الحرج لبيانات الـ حملة / Critical Data Limitation
**`LOCAL-ARTIFACT`: كل ملفات `runtime/` و`logs/` في الجهاز المحلي هي **محاكاة PAPER / رموز صناعية**، وليست حملة Railway الحيّة:**
- `logs/decision_journal.jsonl` (المجلد الجذر، 646 سطر، 11/9 10:33 → 13/9 10:03 UTC): رموز `WAVES/USDT:USDT`, `FC`, `GHOST`, `DRILL*`, `BRK`, `ATOMX`, `PREP`... (رموز اختبار).
- `runtime/trade_state.json` و`trade_lifecycle.jsonl` (12,723 سطر PAPER) و`setup_outcomes.jsonl` (800): صفقات سعرية صناعية (BTC entry=60000) وبوضع `PAPER` — وهي نفس ملفات آخر smoke-test محلي.
- `BARON/logs/decision_journal.jsonl` (111MB، 9/7 → 9/10 UTC): 102K حدث، رموز واقعية مخفية مع رموز اختبار، لكن أسعار `TRADE_OPENED` صناعية (BTC@60000 ...) — تبقى **محاكاة PAPER طويلة**، ليست LIVE.
- كلها تتوقف قبل لحظة الـ deploy الحالي؛ **لا يوجد أي telemetry من مثيل Railway الحيّ محلياً.**

لذلك أي رقم تقني في هذا التقرير هو **خصائص BOOT-LEVEL للكود** (بوابات وترتيبها وحدودها) المدعومة من الشيفرة، وليس قياساً حقيقياً للحملة. القياس الحقيقي موجود فقط على Railway — قسم 20 يعطيك استخراجه الدقيق.

## 5. النظام قيد التحليل / Analyzed System
- الريبو: `https://github.com/rashad99k-sketch/ELABARO--atom` — أعلى مستوى هو canonical؛ نسخ `BARON/` و`SAR_ATOM/` قديمة ودخيلة.
- **الـ commit المنشور المفترض: `5d26b69`** ("Fix Fast Institutional Bridge and harden BingX 101205 close verification") — `origin/main == 5d26b69`، وقت الـ commit 10:04 UTC، وكل توقف الملفات المحلية 10:03 UTC — أي أن آخر حملة محلية اختبارية تزامنت مع آخر commit ثم نُشر على Railway.
- السلسلة: `main.py → app/bootstrap.py → core/runtime.py` → `grid: portfolio_loop`.
- الوحدات: `core/engine.py` (16498 سطر) ، `scanner/scanner.py` ، `scanner/deep_scanner.py` ، `portfolio/manager.py` ، `portfolio/allocator.py` ، `dashboard/app.py` ، `config/settings.py` ، `forensic_pipeline.py` ، `baron_zone_judge.py` (وحدة إضافية لا تُستدعى من المسار الحي — استنتاج: لا علاقة لها بالتنفيذ).

## 6. المحفظة والرموز / Portfolio & Universe
- `DEEP_SCANNER` يبني Universe متوازناً (crypto + TradFi: `scanner/universe.py`) ويعيّن watchlist ديناميكية 50–60 رمزاً (config: `DEEP_WATCHLIST_SIZE=60`، `WATCHLIST_DEEP_BATCH_SIZE=10`، `WATCHLIST_DEEP_INTERVAL_SEC=10`).
- الحدود: `MAX_OPEN_POSITIONS=6`، `MAX_TECHNICAL_POSITIONS=5`، أخبار = 1 سلوت مستقل (`NEWS_SLOT_ENABLED=True`).
- `PORTFOLIO_MARGIN_CAP_PCT=0.60`، `POSITION_MARGIN_PCT=0.10`، `LEVERAGE=10`.
- `PORTFOLIO` يخدم رمزاً-رمزاً (منفصلة الحالة)، و`can_open` يمنع فتح جديد إذا: رمز موجود، أو بلغ الحد الكلي، أو خطر الـ risk_guard يرفض، أو بلغ حد فئة NEWS/technical/لكل class (manager.py:161-175).

## 7. خط زمني النشر / Deployment Timeline
| UTC | الحدث |
|---|---|
| 9/13 10:03 | توقف كل artifacts المحلية (آخر اختبار PAPER شامل) |
| 9/13 10:04 | commit `5d26b69` (fix bridge + close-hardening) |
| ≈9/13 12:07 | انطلاقة ربما لحملة Railway (9 ساعات قبل اللقطة 21:07) — `INFERRED` |
| 9/13 13:00–21:00 | الـ Pipeline يسجل Promoted=7888 / Re-evaluated=442 / Ready=0 / Executed=0 |

## 8. بيانات الـ runtime المحلية (ما هي وماذا لا تعني) / Artifacts
- أهم ما تقدمه الملفات المحلية هو إحصاء أحداث البوابات (قيم تصميمية للاختبار، كلها PAPER/صناعية):
  - QUEUE VETO: READY=121، PRICE_EXTENDED=100، ZONE_STALE=94، ZONE_INVALIDATED=42 (من 357 حدث)
  - EXECUTION VETO: EXECUTED=51، DATA_REJECT=50، LIQUIDITY_REJECT=40، EXECUTION_REJECT=29، MARGIN_CAP_REJECT=20، ENTRY_QUALITY_REJECT=18 (من 229 حدث)
  - PROMOTION VETO: ENTRY_WINDOW_MISSED=22؛ NEWS VETO: NEWS_REACTION_WAIT=21؛ RISK VETO: ALLOCATOR_REJECT=17.
- **دلالة الفئتين كلها PAPER/صناعية.** المحصلة المفيدة: مجموعة البوابات **قابلة للتحقيق مبدئياً** (وصلت READY=121 مرة في المحاكاة و EXECUTED=51 مرة) — أي أن الصفر الحيّ ليس "بوابة مستحيلة" بل ظرف حملة (بيانات/سوق/إعداد).
- الـ boundary الآخر: `pipeline.execution` عدادات الحالة الأخيرة (`last_outcome`) و`exec_pipe` لا تُصدَّر في `runtime/` المحلي — تُقرأ من `/data`.

## 9. بنية البيبلين (المسار القانوني) / Pipeline Architecture
```
Discovery (15min) → DeepScanner.scan → watchlist (50-60)
   → monitor_watchlist (كل 20s، دفعات من 10، بالعمال) → _analyze_symbol
        → _institutional_bridge → InstitutionalRadar registrar → MEMORY["institutional_zone_analysis"]
   → promote_to_queue (scanner.py:1074، كل 20s) → ExecutionQueue.add_candidate
   → queue.re_evaluate_all (كل 5s) → _update_zone_lifecycle/_is_extended/gates → _update_state → READY؟
   → _execute_ready_queue_candidate (كل دورة) → allocator → PORTFOLIO.open_candidate → engine.execute_entry
```
التنفيذ **لا يتم عبر المسح**؛ الماسح لا يضع أوامر إطلاقاً (runtime.py:313-318).

## 10. بوابة الادخال الذكية (Fast Institutional Bridge) / Bridge
- مالئم للدخول في الطابور = `entry.deep_analyzed && entry.institutional_zone_active && (a_grade_ready OR (institutional_prepared && precursor_count>=2))` (scanner.py:1103-1121).
- `_institutional_bridge` (deep_scanner.py:1412) يُسجّل عبر `InstitutionalRadar` مخصص (`_institutional_registrar`)، يحسب `_update_a_grade_status` + `_sync_institutional_zone_registry` (engine.py:13602/13513).
- **الـ commit `5d26b69` أصلح انهياراً حقيقياً** (كان سيوقف كل شيء): كان bridge يستدعي registrar methods على `E.queue` (ExecutionQueue) الذي لا يملكها → AttributeError → سجل تسجيل فارغ → `promote_to_queue` عائد مبكر → صفر طابور. الآن المُقيِّم `self._institutional_radar` مرتبط بـ `E.queue` (لأنه يملك `_select_strong_ob`/`_evaluate_liquidity`/`_evaluate_structure` — deep_scanner.py:1024-1031) والتسجيل على `InstitutionalRadar` — **صحيح في النسخة المنشورة**.
- **عيب**: `_institutional_bridge` (deep_scanner.py:1437) يتطلب `float(score) >= PRE_STRONG_SCORE(6.0)` و `pre_expansion_state` و `precursor_evidence >= 1`. لو السوق هادئ والـ radar scores دون 6.0 **غالبية الوقت**، فالوصلية قليلة لكن ليست صفراً (الأرقام تُظهر ذلك).
- **عيب موثق**: `analysis.roro_signal` ثابت `False` في كائن الـ watchlist (deep_scanner.py:1115) → `a_grade_ready` لن يساوي True عبر المسار الحي → الطابور يدخل عبر `PREPARED` فقط، ومسار A-GRADE fast-confirm عبر المسار الحي (engine.py:16334 `min_confirmations=1`) **ميت عملياً إلا إذا رفع `check_institutional_entry` قيمة roro داخل الـ queue**.

## 11. بوابة القبول في الطابور / Promotion Gate
`scanner.promote_to_queue` (1074-1307) — بعد الفلاتر أعلاه يتطلب:
- مرحلة `pre_expansion.phase` ليست OVEREXTENDED/EXHAUSTION/INVALIDATED (1150)
- للـ A-GRADE: `structural_hits >= 2`؛ للـ PREPARED: `>=1` أو `precursor_count>=2` (1140-1145)
- بيانات طازجة: `get_ohlcv_safe(sym,100)` بطول ≥30، وdistance من الـ causal OB ≤ `QUEUE_MAX_EXTENSION_ATR=1.5` — خلافاً ذلك: `ENTRY_WINDOW_MISSED` (1171-1179، صوت في journal)
- فحص `stale_zone_guard` (1181-1186) و `already_in_queue` (1153) و `no_fresh_data` (1159)
- `add_candidate`: يحفظ 15، **عند الامتلاء يطرد الأقل درجةً غير-READY بصمت** — `total_rejected += 1` فقط؛ حتى `gate_stats["evicted_capacity"]` **لا يزداد أبداً** (engine.py:14538-14548). **فقد صامت غير مُحتسَب في الـ Re-evaluated.**

## 12. بوابة READY (كل البوابات مرتبة) / Readiness Gate Stack
`re_evaluate_all` (engine.py:14558) ثم `_update_state` (16104) — ترتيب الفحص في كل دورة 5s:
1. **التغذية/البيانات**: إطار OHLCV صالح بطول ≥30 من `get_ohlcv_safe(sym,100)` → وإلا `insufficient_data` + invalidate.
2. **حركة المرحلة**: إن `QUEUE_MATURITY_HARD_GATE=1` و`move_maturity ∈ {LATE_EXPANSION, EXHAUSTION}` → `MOVE_MATURITY_REJECT` (افتراضياً 0 → غير مفعّل).
3. **دورة الـ zone** (`_update_zone_lifecycle`): المسافة >1.5 ATR مرتين = `ZONE_STALE` أو `EXPANDED_AWAY`؛ اختراق السعر لعكسة الـ zone = `ZONE_INVALIDATED`.
4. **الامتداد** (`_is_extended`): `|price - zone_mid| > 1.5*ATR` → `PRICE_EXTENDED` → إرجاع للـ watchlist.
5. **كسر الـ OB**: سعر يتجاوز 0.8 ATR عبر عكسة الـ zone → `ORDER_BLOCK_BROKEN` → invalidate.
6. **الدرجات السبعة**: `ZoneMetrics.final_zone_score` (weight: OB .12، zone .18، liquidity .18، inst .15، structure .15، timing .10، trend .05، risk .07) + `confluence_bonus` حتى 5 + انزياح Sniper/Early (محدودة).
7. **الترگر** (`_detect_trigger_state`): من `MSS_CONFIRMED`/`LIQUIDITY_SWEEP`/`BOS_CONFIRMED`/`CHOCH_CONFIRMED` (+`RETEST_CONFIRMED` للـ PREPARED فئة).
8. **التثبيت** (`_update_confirmation`): PREPARED/A-GRADE يحتاج **حدث واحد** مُفرّد؛ العادي **حدثين مُفرّدين**؛ تعريف "الحدث المفرّد" (`_confirm_marker`): `trigger_state | bar_count(=100 دائماً) | sweep_age | int(price/atr)` — أي أحداث مميزة تتطلب تغيّراً في (الترگر أو عمر السويب أو سلة السعر/ATR). **قضبان/إطار واحد = لا تكرار تثبيت.**
9. **ATOM** (إذا مفعّل): `atom_approved && !atom_hard_reject` (REVERSAL يتطلب sniper confirmation).
10. **ADX** (class band): CRYPTO [16,55]، INDEX [18,60]، STOCK [16,55]، GOLD [18,60]، OIL [18,60]، NEWS [16,70] (engine.py:2781-2786). `cand.latest_adx` يُحسب على نفس الإطار.
11. **الدرجة الحاسمة**: `final_zone_score >= class ready_score` — **CRYPTO=68، INDEX=68، STOCK=67، GOLD=70، OIL=70، NEWS=70** (الافتراضي في `MarketBehaviorProfile.ENTRY_PROFILES`).
12. **نافذة/دليل**: `zone_state ∈ {ENTRY_WINDOW, RETEST, ACTIVE}` + `decision_label` لا يبدأ بـ INVALID (`_classify_decision`).

**ترتيب الـ blocker الأول (بالأولوية)**: `CONFIRMATION > TRIGGER > ADX > ATOM_HARD_REJECT > ATOM > READY_SCORE_FLOOR > ZONE_WINDOW > EVIDENCE` (engine.py:16182-16213) — dashboard يخبرك بالسبب الحرفي لأي مرشح عبر `ready_blocker`.

## 13. بوابة التنفيذ / Execution Gates
`_execute_ready_queue_candidate` (runtime.py:312) — حتى مَن وصل READY يُفحص:
- **kill switch** نشط → `kill_switch`
- **سلوت**: `max_positions - count() <= 0` → `no_slots`
- `get_best_candidate` → `none` → `no_ready_candidate`؛ وإذا `READY` و`priority_score < QUEUE_MIN_READY_SCORE` (افتراضي **75**) → `ready_score_below_min` (runtime.py:360).
  — **التفاوت الحاسم الموثق**: درجة READY بالفئة (68–70) مقابل حد التنفيذ الثاني (75) — فمَن وصل READY بدرجة [68, 74.9] **يُرفض حتماً** في التنفيذ مع بقائه READY في الطابور.
- **news_risk ≥ 80** → `news_risk_block`
- **المخصص** (`GlobalAssetAllocator`): يعيد فحص caps فئات/اتجاهات → `allocator_reject` (+RISK/ALLOCATOR_REJECT في الـ journal)
- `PORTFOLIO.open_candidate(candidate)` (`manager.py:275`) → `can_open` (سلوت/خطر/فئة) → `execute_entry` (engine.py:8447) → gate كامل:
  - OHLCV صحيح (غير → `DATA_REJECT`)
  - **ADX مرة أخرى** بنفس band الفئة (غير → `ADX_REJECT`)
  - `detect_liquidity_context == المتوقع` (BUY→`sell_side_taken`) (غير → `LIQUIDITY_REJECT`) + فحص fake sweep
  - `ENTRY_QUALITY_AUTHORITY` إن `true` (افتراضي OFF → غير مفعّل) → `ENTRY_QUALITY_REJECT`
  - سقف margin PAPER (`PORTFOLIO_MARGIN_CAP_PCT`)
- التالي: `pipeline.execution` يزيد النتيجة (executed / open_candidate_failed / ...) (runtime.py:450-459).

## 14. الدورة الحية / Live Loop Cadence (runtime.py:548-649)
- `GLOBAL_SCAN_INTERVAL_SEC` (900s) → `_run_discovery`
- `WATCHLIST_SERVICE_INTERVAL_SEC` (20s) → `_service_watchlist_and_queue` (رادار + مراقبة + ترقية + تنظيف `WATCHLIST_EXPIRE_AFTER_SEC=600`)
- `QUEUE_RE_EVAL_INTERVAL` (5s) → `queue.re_evaluate_all(get_ohlcv_safe(sym,100))`
- بعدها فوراً `_execute_ready_queue_candidate()` ثم `news_slot`
- `queue.cleanup()` كل دورة: أي مرشح في الطابور **أكثر من ساعة يُرجَع للـ watchlist ويُحذف** (engine.py:16396 `expired`) — **قيد قاتل محتمل: تثبيت/انتظار يتجاوز ساعة = فقد صامت وإن كان الرمز حياً.**
- `PORTFOLIO.manage_all()` يخدم الفتحات أولاً.

## 15. التناقضات الحاسمة المستخرجة من الكود / Hardened Threshold Mismatches
1. **READY floor vs Execution floor**: `ready_score` الفئة (68–70) يُعرّف READY، لكن التنفيذ يعرقل على `QUEUE_MIN_READY_SCORE=75` (runtime.py:360). READY حقيقي متاح فقط إذا `final_zone_score ≥ 75` في نفس الوقت مع كل باقي البوابات — عملياً هذا يرفع الـ READY الحقيقي كثيراً ويخلق "READY بحسب الكود لكن مرفوض في التنفيذ".
2. **مفهوم الحدث المُفرّد للتثبيت**: `bar_count = len(df) = 100` ثابت؛ التثبيت الثاني/الأول لغير PREPARED يتطلب تغيّر `int(price/atr)` أو عمر السويب — في سوق هادئ/متراوح هذا يبقي المرشحين عالقين في `WAITING_TRIGGER` فترات طويلة حتى يُجليهم `expired` (1h).
3. **ADX مزدوج الفحص**: في `_update_state` (16160) و`execute_entry` (8532) بنفس الـ band — القصد هو التوافق، لكن أي انحراف بين ADX لحظة READY ولحظة التنفيذ (الفارق ثوانٍ) يعني `ADX_REJECT` إضافي.
4. **`data_age > 900` يعلّق** أي رمز `STALE` في الـ watchlist (deep_scanner.py:908) — لو BingX feed متقطع/متأخر (حالة شائعة مع `QUIET`/مؤشرات)، الكل يبقى غير قابل للترقية.
5. **News slot عدم إفادة**: `NEWS_SLOT_ENABLED=True` لكن يتطلب تفاعل سعري موثّق بعد الخبر (`NEWS_REACTION_WAIT`) — في غياب تفاعل حي، يبقى `news_waiting_reaction` والصفر يبقى.
6. **`baron_zone_judge` غير موصل** — بدون أثر حي (ليس عيباً بل ملاحظة أثر).

## 16. دلالة العدادات / Counter Semantics
- `Promoted` **تراكمي ويتضاعف** بإعادة إضافة الرمز ذاته بعد كل `_return_to_watchlist`/`expired` — 7888 لا يعني 7888 صفقة مميزة.
- `In Queue` = حجم آني (15/15) — الطابور ممتلئ والطرد صامت.
- `Re-evaluated` = مجموع الأحداث الطرفية في `gate_stats` (تشمل `ready`) — **لكنها لا تشمل** الـ `expired` ولا `evicted_capacity` ولا حالات `WAITING_TRIGGER` المستمرة. أي الـ 442 تحتها ضوضاء عن الحالات القاتلة فقط.
- `Ready` (بطاقة) = آني، `Executed` = تراكمي منذ الإقلاع.
- الـ `gate_stats` يراها كلها في `/data` — القرار الحاسم لنسبة الـ ready من الـ 442 موجود هناك فقط.

## 17. أين تُفقد الفرص على الأرجح (مرتب حسب الأدلة) / Where Opportunities Are Lost
`CODE-VERIFIED` احتمالي لحملة أرقامها متطابقة مع الفرضيات المذكورة:

1. **عقبة الإثبات/الترگر (الممر الحرج الأول)**: مع Queue ممتلئة 15/15، معظم المرشحين عالقون `WAITING_TRIGGER`/`GOOD_ZONE` ولا تصلهم (a) ترگر مثبت (سويپ+بنية+رفض) ولا (b) حدث ثانٍ مفرّد خلال حياتهم. المقياس: `gate_stats.ready` داخل الـ 442 — إن كان صفراً فالبوابة الأولى هي السبب.
2. **الحذف الصامت/الطرد/الانتهاء**: `expired` (1h) + `evicted_capacity` غير العدَّاد + `PRICE_EXTENDED` يرجّع؛ مع Promotions=7888 مقابل Re-evaluated=442 فهناك دورة إعادة إضافة ضخمة = الطابور يعيد تدوير نفس الرموز دون أن تنضج.
3. **قاع التنفيذ 75 / بوابتا ADX وLiquidity في التنفيذ**: حتى المرشح READY الصحيح يُرفض من `ready_score_below_min` أو `ADX_REJECT` أو `LIQUIDITY_REJECT` أو `ALLOCATOR_REJECT` قبل فتح الصفقة. المقياس: `pipeline.execution` العدادات + سجل EXECUTION VETO.
4. **البيانات**: `data_age>900=STALE` و`insufficient_data` لو تغذية OHLCV/BingX تتأخر — مقياس: حصص `gate_stats.insufficient_data` و`DATA_REJECT`.

## 18. تصنيف مصدر الجذر / Root-Cause Classification (Stage Rating)
| الصنف | الوزن | الدليل المحتمل |
|---|---|---|
| **Gate (بوابات READY/التنفيذ)** | عالي جداً | الترتيب الكامل 12 بوابة، و READY=0 رغم طابور ممتلئ 15، ومعدل قاع 75/68-70، ومفهوم "الحدث المفرّد" |
| **Runtime lifecycle** (الانتهاء 1h، الطرد الصامت، إعادة التدوير) | عالي | `cleanup()`/`add_candidate` مع Promotions=7888 و Queue=15 |
| **Data** | متوسط | `data_age>900` و`insufficient_data` و`DATA_REJECT` (في المحاكاة 50 حدثاً) — يحتاج تأكيد من LIVE |
| **Strategy/Signal** | متوسط | سرعة ترگر/سويپ في سوق 9 ساعات؛ لو `gate_stats.ready` في الـ 442 عدد كبير فعلاً فالبوابة الأخيرة (تنفيذ) هي السبب لا الاستراتيجية |
| **Pipeline/Structure** | منخفض | السلسلة مبنية، ومُحاولة: bridges أُصلحت؛ لا يوجد path كامل مكسور — إلا أن `roro_signal=False` في الـ watchlist يموّت مسار A-GRADE (ثغرة بنائية موثقة) |

## 19. أعلى 3 أسباب مدعومة بالأدلة (مع اختبار التفنيد) / Top-3 Causes
### السبب المحتمل الأول: شروط READY الكاملة لا تُستوفى معاً خلال دورة حياة المرشح
- الأدلة: كل بوابات READY الثمانية (12) إجبارية في نفس اللحظة؛ `Ready=0` آنياً و`Promoted=7888` و`Re-evaluated=442` = حالة "طابور يدار ولا ينضج"؛ إعادة تدوير سريعة تنقّل بين الطابور وwatchlist قبل اكتمال ترگر+تثبيت.
- **اختبار التفنيد (من Railway)**: اقرأ `gate_stats.ready` في `/data`. إن كانت **>0** فالبوابة الأولى ليست السبب الوحيد — الحالات وصلت READY ويجب الانتقال للسبب الثالث.

### السبب المحتمل الثاني: عمر المرشح في الطابور 1 ساعة + الطرد الصامت + الـ PRICE_EXTENDED تُهدر الفرص قبل نضجها
- الأدلة: `cleanup()` (engine.py:16396) يسحب أي مرشح فوق ساعة؛ `add_candidate` (14538) يطرد الأقل درجةً بدون أي عدّاد؛ `PRICE_EXTENDED`/`ZONE_STALE` (14638-14643، 15062) ترجّع المرشحين؛ الرمز يُعاد ترقيته → Promotions تضخم.
- **اختبار التفنيد**: اقرأ `gate_stats`: لو `expired+zone_stale+extended+zone_invalidated` ≈ 442 (أو أغلبها) والـ `ready` ≈ 0 → هذا السبب هو المتحكم. لو `score_too_low` طاغي → السبب الأول/الثالث أكثر رجحاناً.

### السبب المحتمل الثالث: قاع التنفيذ 75 ومرشحات ADX/Liquidity/ALLOCATOR الثانية ترفض حتى مَن اكتمل READY
- الأدلة: `ready_score` الفئة 68–70 مقابل `QUEUE_MIN_READY_SCORE=75` (runtime.py:360)؛ إعادة فحص ADX (8532) و`detect_liquidity_context` (8553-8566) في `execute_entry` ودائرة `ALLOCATOR_REJECT` (runtime.py:410)؛ وفي المحاكاة EXECUTION VETO يشمل DATA_REJECT=50 / LIQUIDITY_REJECT=40 / MARGIN_CAP_REJECT=20 — إشارة إلى أن هذه البوابات حقيقية الفعل.
- **اختبار التفنيد**: اقرأ `pipeline.execution` من `/data` — تفعيل `executed` لو `gate_stats.ready>0` وإلا فحص `ready_score_below_min` و`allocator_reject` و`open_candidate_failed` و`no_slots`.

## 20. خطوات استخراج الأدلة القاطعة من Railway / Decisive Evidence Runbook
اقرأ هذه القنوات من مثيل Railway (أو من ملفات `runtime/` المنزّلة من الخادم):
1. `GET /data` → انسخ `pipeline` كاملاً + `queue.gate_stats` + `queue.candidates[]` (15 مرشحاً بأعمدته: `state, ready_blocker, gate_status, trigger, score, zone_state, conf, latest_adx`).
2. ثم اقرأ الأسطر في `decision_journal.jsonl` الحيّ للمثيل وجمّع `stage/decision/reason` كما في القسم 8؛ لاحظ الرموز الحقيقية (BTC/ETH/XAU/WTI/US500/NVDA...).
3. من لوحة المتصفح: اقرأ عمود `state` لكل صف من صفوف Queue — لتحديد نسبة `WAITING_TRIGGER`/`GOOD_ZONE`/`WATCHLIST`/`READY`/`RETURNED_WATCHLIST`.
4. `GET /execution` و`/queue` — نفس البنى.
5. من سجل الـ runtime: `[A-GRADE]`, `[ATOM-INTEL]`, `[EXPANSION]`, `[CONFIRMATION]`, `[QUEUE] *.REJECT/PRICE_EXTENDED/ZONE_STALE/EXPIRED`, `[ENTRY] *REJECT/ADX/LIQUIDITY`, `[PORTFOLIO] *reject*`.
6. أكّد القيم البيئية الحية (env على Railway): `PAPER_MODE`, `QUEUE_MIN_READY_SCORE`, `QUEUE_MAX_SIZE`, `QUEUE_MATURITY_HARD_GATE`, `ENTRY_QUALITY_AUTHORITY`, `NEWS_SLOT_ENABLED`, `DATA_FABRIC_ENABLED`, `INSTITUTIONAL_ZONE_MAX` — فحالة `PAPER_MODE=True` غريبة على "LIVE" الذي تصفه.
7. (اختياري) `python forensic_pipeline.py` محلياً يعيد تشغيل البوابات الحقيقية بأدوات إنتاجية — لا ينفّذ أوامر — لتوليد قياس محدد لقيم الـ env الحالية.

---

## الإجابة المباشرة على الأسئلة الأربعة / Direct Answers

1. **لماذا Executed=0 حتماً في LIVE؟** لا يمكن إثبات القياس من محلي؛ الأدلة تحصر في: (أ) لا مرشح تكمل READY الكامل (بوابات 12) خلال ≤1 ساعة في الطابور؛ أو (ب) مَن أكمل READY يُرفض في التنفيذ عند قاع 75 / ADX / Liquidity / ALLOCATOR قبل فتح الصفقة؛ وليس بسبب البنية (الـ bridge مُصلَح، والتنفيذ عبر `PORTFOLIO→execute_entry` يعمل). القياس الحاسم: `gate_stats.ready` و`pipeline.execution` في `/data`.

2. **أقرب الرموز لـ READY ومن فشل ولماذا؟** المعرفة فقط بالكود: هم المرشحون `institutional_prepared` الذين بلغوا `RETEST_CONFIRMED`/ترگر مثبت مع درجة ≥ 68–70 — أي قد يكتملون لو جمعوا ADX في band والسوق/البنية توافقت في نفس اللحظة قبل ساعة من عمر الطابور. لا يمكن تسمية الرموز الحية دون `/data`. (في المحاكاة، WAVES/BTC/FC/... وصلوا READY أكثر من مرة.) منفذ إيجابي: انسخ `queue.candidates[]` بعمود `ready_blocker` لترى بالعيْن لماذا كل واحد فشل — القيادة من الكود: أغلب الـ blockers `CONFIRMATION` ثم `TRIGGER` ثم `ADX` ثم `READY_SCORE_FLOOR`.

3. **أين تُفقد الفرص بالضبط؟** مرحلتان حاسمتان: (1) داخل الطابور بين القبول و READY — عالقون على تثبيت/ترگر حتى يُجليهم `expired`(1h) أو `PRICE_EXTENDED`/`ZONE_STALE` أو الطرد الصامت عند الامتلاء؛ (2) بين READY والتنفيذ — قاع 75 / ADX / Liquidity / ALLOCATOR. وعيب صامت بنيوي: مسار A-GRADE ميت لأن `roro_signal=False` في الـ watchlist (deep_scanner.py:1115).

4. **المصدر؟** الترتيب: **Gate** (بوابات READY/التنفيذ) ثم **Runtime lifecycle** (انتهاء 1h/طرد/إعادة تدوير) ثم **Data** (STALE/insufficient) ثم **Strategy** (ترگر/سويپ قليلة) ثم **Pipeline structure** (خطأ بنيوي صغير: roro_signal).

> **نصيحة فورية (تحتاج موافقتك، لن أنفّذ شيئاً):** بعد التحقق من `gate_stats`، الخطوة الأعلى أثراً دون مساس بالأمان هي إما رفع عمر الطابور من 1h (تعديل `cleanup`/`expires`) إلى 6–24h + خفض `QUEUE_MIN_READY_SCORE` إلى مساواة `ready_score` الفئة (68–70)، أو تفعيل توزيع `ready_blocker` كمصدر قرار قبل أي تغيير آخر.